import math
from pathlib import Path

import folium
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium
from streamlit_searchbox import st_searchbox

from optimizer import optimize_warehouses


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="GRIDPOINT",
    page_icon="📍",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# GLOBAL CSS
# ============================================================

st.markdown(
    """
    <style>

    /* Main application */
    .stApp {
        background-color: #f5f7fb;
    }

    .block-container {
        padding-top: 1.5rem;
        padding-bottom: 3rem;
        max-width: 1500px;
    }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background-color: #0b1220;
    }

    section[data-testid="stSidebar"] * {
        color: white;
    }

    section[data-testid="stSidebar"] input {
        color: white !important;
        background-color: #172033 !important;
    }

    section[data-testid="stSidebar"] label {
        color: #d9e1ee !important;
    }

    /* Buttons */
    .stButton > button {
        border-radius: 10px;
        min-height: 42px;
        font-weight: 700;
    }

    /* Inputs */
    div[data-baseweb="input"] > div {
        border-radius: 10px;
    }

    /* Searchbox */
    [data-testid="stSearchbox"] {
        width: 100%;
    }

    /* Metric cards */
    [data-testid="stMetric"] {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 15px;
        padding: 18px;
        box-shadow: 0 3px 12px rgba(0,0,0,0.04);
    }

    [data-testid="stMetricLabel"] {
        font-weight: 700;
    }

    [data-testid="stMetricValue"] {
        font-weight: 800;
    }

    /* Dataframes */
    [data-testid="stDataFrame"] {
        border-radius: 12px;
        overflow: hidden;
    }

    /* Horizontal divider */
    hr {
        border-color: #e2e8f0;
    }

    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# BENGALURU LOCATION DATABASE
# ============================================================

BENGALURU_PLACES = [
    # South Bengaluru
    ("Basavanagudi", 12.9416, 77.5752),
    ("Gandhi Bazaar", 12.9450, 77.5700),
    ("Jayanagar", 12.9250, 77.5938),
    ("Jayanagar 1st Block", 12.9310, 77.5910),
    ("Jayanagar 2nd Block", 12.9280, 77.5900),
    ("Jayanagar 3rd Block", 12.9230, 77.5910),
    ("Jayanagar 4th Block", 12.9190, 77.5930),
    ("Jayanagar 5th Block", 12.9140, 77.5930),
    ("Jayanagar 6th Block", 12.9180, 77.5850),
    ("Jayanagar 7th Block", 12.9220, 77.5800),
    ("JP Nagar", 12.9063, 77.5857),
    ("JP Nagar 1st Phase", 12.9060, 77.5850),
    ("JP Nagar 2nd Phase", 12.9010, 77.5850),
    ("JP Nagar 3rd Phase", 12.8960, 77.5890),
    ("JP Nagar 4th Phase", 12.9090, 77.5800),
    ("JP Nagar 5th Phase", 12.8950, 77.6020),
    ("JP Nagar 6th Phase", 12.8910, 77.6030),
    ("JP Nagar 7th Phase", 12.8870, 77.5960),
    ("Banashankari", 12.9255, 77.5468),
    ("Banashankari 1st Stage", 12.9380, 77.5500),
    ("Banashankari 2nd Stage", 12.9270, 77.5480),
    ("Banashankari 3rd Stage", 12.9160, 77.5510),
    ("Padmanabhanagar", 12.9150, 77.5550),
    ("Kumaraswamy Layout", 12.9060, 77.5600),
    ("BTM Layout", 12.9166, 77.6101),
    ("BTM Layout 1st Stage", 12.9160, 77.6050),
    ("BTM Layout 2nd Stage", 12.9110, 77.6100),
    ("Koramangala", 12.9352, 77.6245),
    ("Koramangala 1st Block", 12.9380, 77.6200),
    ("Koramangala 2nd Block", 12.9320, 77.6200),
    ("Koramangala 3rd Block", 12.9290, 77.6250),
    ("Koramangala 4th Block", 12.9340, 77.6300),
    ("Koramangala 5th Block", 12.9340, 77.6150),
    ("Koramangala 6th Block", 12.9380, 77.6150),
    ("Koramangala 7th Block", 12.9410, 77.6150),
    ("HSR Layout", 12.9116, 77.6389),
    ("HSR Layout Sector 1", 12.9160, 77.6400),
    ("HSR Layout Sector 2", 12.9110, 77.6450),
    ("HSR Layout Sector 3", 12.9070, 77.6400),
    ("HSR Layout Sector 4", 12.9030, 77.6380),
    ("HSR Layout Sector 5", 12.9080, 77.6480),
    ("Electronic City", 12.8452, 77.6602),
    ("Electronic City Phase 1", 12.8390, 77.6650),
    ("Electronic City Phase 2", 12.8320, 77.6780),
    ("Bommanahalli", 12.9070, 77.6240),
    ("Begur", 12.8770, 77.6240),
    ("Arekere", 12.8860, 77.5960),
    ("Bannerghatta Road", 12.8880, 77.5940),

    # East Bengaluru
    ("Indiranagar", 12.9784, 77.6408),
    ("Indiranagar 1st Stage", 12.9780, 77.6350),
    ("Indiranagar 2nd Stage", 12.9780, 77.6450),
    ("Domlur", 12.9600, 77.6387),
    ("HAL", 12.9600, 77.6500),
    ("Ulsoor", 12.9810, 77.6200),
    ("CV Raman Nagar", 12.9850, 77.6630),
    ("Kaggadasapura", 12.9850, 77.6750),
    ("Marathahalli", 12.9591, 77.6974),
    ("Brookefield", 12.9660, 77.7150),
    ("Whitefield", 12.9698, 77.7500),
    ("ITPL", 12.9850, 77.7370),
    ("Kadugodi", 12.9900, 77.7580),
    ("Varthur", 12.9400, 77.7470),
    ("Bellandur", 12.9250, 77.6760),
    ("Sarjapur Road", 12.9100, 77.6870),

    # North Bengaluru
    ("Hebbal", 13.0358, 77.5970),
    ("RT Nagar", 13.0200, 77.5950),
    ("Sanjay Nagar", 13.0400, 77.5800),
    ("Yelahanka", 13.1007, 77.5963),
    ("Yelahanka New Town", 13.0980, 77.5800),
    ("Jakkur", 13.0780, 77.6060),
    ("Thanisandra", 13.0580, 77.6350),
    ("Hennur", 13.0290, 77.6400),
    ("Kalyan Nagar", 13.0220, 77.6380),
    ("Kammanahalli", 13.0150, 77.6370),
    ("Nagawara", 13.0380, 77.6200),

    # West Bengaluru
    ("Rajajinagar", 12.9910, 77.5540),
    ("Malleshwaram", 13.0030, 77.5700),
    ("Vijayanagar", 12.9710, 77.5350),
    ("Nagarbhavi", 12.9590, 77.5120),
    ("Kengeri", 12.9170, 77.4870),
    ("Nayandahalli", 12.9420, 77.5240),
    ("Peenya", 13.0280, 77.5190),
    ("Basaveshwaranagar", 12.9910, 77.5400),
    ("Kamakshipalya", 12.9820, 77.5250),
]


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def safe_number(value, default=0.0):
    try:
        if value is None:
            return default

        if isinstance(value, str):
            cleaned = (
                value.replace("₹", "")
                .replace(",", "")
                .replace("%", "")
                .strip()
            )

            if cleaned == "":
                return default

            return float(cleaned)

        number = float(value)

        if math.isnan(number):
            return default

        return number

    except Exception:
        return default


def search_bengaluru_places(searchterm):
    """
    Live autocomplete search.
    Returns strings because streamlit-searchbox expects strings.
    """

    if not searchterm:
        return []

    query = searchterm.strip().lower()

    if not query:
        return []

    exact = []
    starts = []
    contains = []

    for name, lat, lon in BENGALURU_PLACES:
        name_lower = name.lower()

        if name_lower == query:
            exact.append(name)

        elif name_lower.startswith(query):
            starts.append(name)

        elif query in name_lower:
            contains.append(name)

    return (exact + starts + contains)[:10]


def location_selector(label, key):
    """
    Persistent Bengaluru location selector.

    Important:
    st_searchbox returns a string, not a tuple.
    """

    st.markdown(f"**{label}**")

    selected = st_searchbox(
        search_bengaluru_places,
        placeholder="Type Bengaluru location...",
        key=key,
    )

    state_key = f"{key}_selected"

    if selected:
        st.session_state[state_key] = selected

    selected_name = st.session_state.get(state_key)

    if not selected_name:
        return None

    for name, lat, lon in BENGALURU_PLACES:
        if name == selected_name:
            return {
                "name": name,
                "lat": float(lat),
                "lon": float(lon),
            }

    return None


def make_customer_dataframe(customer_blocks):
    rows = []

    for block in customer_blocks:
        location = block.get("location")
        orders = safe_number(block.get("orders"), 0)

        if not location:
            continue

        if orders <= 0:
            continue

        rows.append(
            {
                "id": location["name"],
                "name": location["name"],
                "latitude": location["lat"],
                "longitude": location["lon"],
                "orders": int(orders),
            }
        )

    return pd.DataFrame(rows)


def make_warehouse_dataframe(warehouse_blocks):
    rows = []

    for index, block in enumerate(warehouse_blocks):
        location = block.get("location")

        if not location:
            continue

        capacity = safe_number(block.get("capacity"), 0)
        fixed_cost = safe_number(block.get("fixed_cost"), 0)

        if capacity <= 0:
            continue

        rows.append(
            {
                "id": f"W{index + 1}",
                "name": location["name"],
                "latitude": location["lat"],
                "longitude": location["lon"],
                "capacity": int(capacity),
                "fixed_cost": fixed_cost,
            }
        )

    return pd.DataFrame(rows)


def generate_warehouse_candidates(customers_df, count=8):
    """
    Generate candidate warehouses around customer demand points.

    The optimizer still decides which candidates to open.
    """

    if customers_df.empty:
        return pd.DataFrame()

    candidates = []

    # Customer coordinates
    customer_points = customers_df[
        ["latitude", "longitude"]
    ].drop_duplicates()

    for index, row in customer_points.head(count).iterrows():

        candidates.append(
            {
                "id": f"CAND-{len(candidates) + 1}",
                "name": f"Auto Warehouse {len(candidates) + 1}",
                "latitude": float(row["latitude"]),
                "longitude": float(row["longitude"]),
                "capacity": 1000,
                "fixed_cost": 5000,
            }
        )

    # Add predefined central locations if required
    if len(candidates) < count:
        for name, lat, lon in BENGALURU_PLACES:

            if len(candidates) >= count:
                break

            candidates.append(
                {
                    "id": f"CAND-{len(candidates) + 1}",
                    "name": f"Auto Warehouse {len(candidates) + 1}",
                    "latitude": float(lat),
                    "longitude": float(lon),
                    "capacity": 1000,
                    "fixed_cost": 5000,
                }
            )

    return pd.DataFrame(candidates)


def normalize_utilization(utilization):
    """
    Converts optimizer utilization output into a safe DataFrame.
    """

    if utilization is None:
        return pd.DataFrame()

    if isinstance(utilization, pd.DataFrame):
        df = utilization.copy()

    elif isinstance(utilization, list):
        df = pd.DataFrame(utilization)

    elif isinstance(utilization, dict):

        rows = []

        for warehouse_id, values in utilization.items():

            if isinstance(values, dict):

                row = dict(values)

                if "Warehouse" not in row:
                    row["Warehouse"] = warehouse_id

            else:

                row = {
                    "Warehouse": warehouse_id,
                    "Utilization": values,
                }

            rows.append(row)

        df = pd.DataFrame(rows)

    else:
        return pd.DataFrame()

    # Remove duplicate columns
    df = df.loc[:, ~df.columns.duplicated(keep="first")]

    rename_map = {}

    for column in df.columns:

        normalized = str(column).lower().strip()

        if normalized in ["warehouse_id", "warehouse", "id"]:
            rename_map[column] = "Warehouse"

        elif normalized in ["assigned_orders", "assigned"]:
            rename_map[column] = "Assigned Orders"

        elif normalized in ["capacity", "max_capacity"]:
            rename_map[column] = "Capacity"

        elif normalized == "remaining_capacity":
            rename_map[column] = "Remaining Capacity"

        elif normalized in [
            "utilization_percent",
            "utilisation",
            "utilization",
        ]:
            rename_map[column] = "Utilization"

    df = df.rename(columns=rename_map)

    df = df.loc[:, ~df.columns.duplicated(keep="first")]

    return df


def normalize_assignments(assignments):
    """
    Converts optimizer assignment output into a displayable DataFrame.
    """

    if assignments is None:
        return pd.DataFrame()

    if isinstance(assignments, pd.DataFrame):
        df = assignments.copy()

    elif isinstance(assignments, list):
        df = pd.DataFrame(assignments)

    elif isinstance(assignments, dict):

        rows = []

        for customer, warehouse in assignments.items():

            if isinstance(warehouse, dict):

                row = dict(warehouse)
                row["Customer"] = customer

            else:

                row = {
                    "Customer": customer,
                    "Warehouse": warehouse,
                }

            rows.append(row)

        df = pd.DataFrame(rows)

    else:
        return pd.DataFrame()

    df = df.loc[:, ~df.columns.duplicated(keep="first")]

    rename_map = {}

    for column in df.columns:

        normalized = str(column).lower().strip()

        if normalized in ["customer", "customer_id", "neighborhood"]:
            rename_map[column] = "Customer"

        elif normalized in [
            "warehouse",
            "warehouse_id",
            "assigned_warehouse",
        ]:
            rename_map[column] = "Warehouse"

        elif normalized in ["distance", "distance_km"]:
            rename_map[column] = "Distance (km)"

        elif normalized in ["orders", "assigned_orders"]:
            rename_map[column] = "Orders"

        elif normalized in ["cost", "delivery_cost"]:
            rename_map[column] = "Delivery Cost"

    df = df.rename(columns=rename_map)

    df = df.loc[:, ~df.columns.duplicated(keep="first")]

    return df


def format_currency(value):
    if value is None:
        return "—"

    number = safe_number(value, None)

    if number is None:
        return "—"

    return f"₹{number:,.2f}"


def format_distance(value):
    if value is None:
        return "—"

    number = safe_number(value, None)

    if number is None:
        return "—"

    return f"{number:.2f} km"


# ============================================================
# SESSION STATE
# ============================================================

if "customer_blocks" not in st.session_state:
    st.session_state.customer_blocks = [
        {
            "location": None,
            "orders": 100,
        },
        {
            "location": None,
            "orders": 100,
        },
        {
            "location": None,
            "orders": 100,
        },
    ]


if "warehouse_blocks" not in st.session_state:
    st.session_state.warehouse_blocks = [
        {
            "location": None,
            "capacity": 1000,
            "fixed_cost": 5000,
        }
    ]


if "optimization_result" not in st.session_state:
    st.session_state.optimization_result = None


if "optimization_inputs" not in st.session_state:
    st.session_state.optimization_inputs = None


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title("GRIDPOINT")

    st.caption("Warehouse Location Optimization")

    st.divider()

    st.subheader("Optimization Settings")

    num_warehouses = st.number_input(
        "Maximum warehouses",
        min_value=1,
        max_value=20,
        value=3,
        step=1,
    )

    cost_per_km = st.number_input(
        "Delivery cost / km",
        min_value=0.0,
        value=10.0,
        step=1.0,
    )

    radius_enabled = st.checkbox(
        "Limit delivery radius",
        value=False,
    )

    if radius_enabled:

        max_delivery_radius = st.number_input(
            "Maximum delivery radius (km)",
            min_value=0.1,
            max_value=100.0,
            value=15.0,
            step=0.5,
        )

    else:

        max_delivery_radius = None

    st.divider()

    st.subheader("Warehouse Source")

    warehouse_mode = st.radio(
        "Choose warehouse locations",
        [
            "Automatic",
            "Manual",
        ],
        index=0,
    )

    st.divider()

    st.caption("GRIDPOINT")
    st.caption("Data-driven logistics optimization")


# ============================================================
# HEADER
# ============================================================

st.title("📍 GRIDPOINT")

st.subheader(
    "Intelligent Warehouse Location Optimization"
)

st.write(
    "Optimize warehouse placement, customer assignments, delivery distance, "
    "capacity utilization and logistics cost using mathematical optimization."
)


# ============================================================
# FEATURE OVERVIEW
# ============================================================

feature_col1, feature_col2, feature_col3, feature_col4 = st.columns(4)

with feature_col1:
    with st.container(border=True):
        st.subheader("📍 Locations")
        st.write("Select Bengaluru demand locations using live search.")

with feature_col2:
    with st.container(border=True):
        st.subheader("📦 Demand")
        st.write("Enter daily order demand for each neighborhood.")

with feature_col3:
    with st.container(border=True):
        st.subheader("🏭 Warehouses")
        st.write("Use automatic or manually defined warehouse candidates.")

with feature_col4:
    with st.container(border=True):
        st.subheader("📊 Optimization")
        st.write("Minimize delivery cost while respecting capacity.")


st.divider()


# ============================================================
# CUSTOMER DEMAND
# ============================================================

st.header("1. Customer Demand")

st.write(
    "Add the neighborhoods that generate orders. "
    "Incomplete locations are ignored during optimization."
)


# Render customer blocks
for index in range(len(st.session_state.customer_blocks)):

    block = st.session_state.customer_blocks[index]

    with st.container(border=True):

        col1, col2, col3 = st.columns([5, 2, 1])

        with col1:

            location = location_selector(
                f"Customer Location {index + 1}",
                f"customer_location_{index}",
            )

            if location:
                block["location"] = location

                st.caption(
                    f"Selected: {location['name']} "
                    f"({location['lat']:.4f}, {location['lon']:.4f})"
                )

        with col2:

            block["orders"] = st.number_input(
                "Daily Orders",
                min_value=1,
                max_value=100000,
                value=int(block.get("orders", 100)),
                step=10,
                key=f"orders_{index}",
            )

        with col3:

            st.write("")

            if st.button(
                "🗑️",
                key=f"remove_customer_{index}",
                help="Remove this neighborhood",
            ):

                if len(st.session_state.customer_blocks) > 1:

                    st.session_state.customer_blocks.pop(index)

                    st.rerun()


st.write("")

if st.button(
    "➕ Add New Neighborhood",
    use_container_width=False,
):

    st.session_state.customer_blocks.append(
        {
            "location": None,
            "orders": 100,
        }
    )

    st.rerun()


# ============================================================
# CUSTOMER PREVIEW
# ============================================================

customers_df = make_customer_dataframe(
    st.session_state.customer_blocks
)

if not customers_df.empty:

    st.subheader("Demand Preview")

    preview_df = customers_df[
        [
            "name",
            "orders",
            "latitude",
            "longitude",
        ]
    ].copy()

    preview_df.columns = [
        "Location",
        "Daily Orders",
        "Latitude",
        "Longitude",
    ]

    st.dataframe(
        preview_df,
        use_container_width=True,
        hide_index=True,
    )

    total_orders = int(customers_df["orders"].sum())

    st.info(
        f"Total daily demand: {total_orders:,} orders "
        f"across {len(customers_df)} neighborhoods."
    )

else:

    st.warning(
        "Add at least one valid customer location with daily orders."
    )


st.divider()


# ============================================================
# WAREHOUSE CONFIGURATION
# ============================================================

st.header("2. Warehouse Configuration")


if warehouse_mode == "Automatic":

    st.info(
        "Automatic mode generates warehouse candidates from the selected "
        "demand locations. The optimizer chooses which warehouses to open."
    )

else:

    st.write(
        "Define the warehouse candidates manually."
    )

    for index in range(len(st.session_state.warehouse_blocks)):

        block = st.session_state.warehouse_blocks[index]

        with st.container(border=True):

            col1, col2, col3, col4 = st.columns(
                [4, 2, 2, 1]
            )

            with col1:

                location = location_selector(
                    f"Warehouse {index + 1}",
                    f"warehouse_location_{index}",
                )

                if location:
                    block["location"] = location

            with col2:

                block["capacity"] = st.number_input(
                    "Capacity",
                    min_value=1,
                    max_value=1000000,
                    value=int(
                        block.get("capacity", 1000)
                    ),
                    step=100,
                    key=f"warehouse_capacity_{index}",
                )

            with col3:

                block["fixed_cost"] = st.number_input(
                    "Fixed Cost",
                    min_value=0.0,
                    max_value=100000000.0,
                    value=float(
                        block.get("fixed_cost", 5000)
                    ),
                    step=500.0,
                    key=f"warehouse_fixed_cost_{index}",
                )

            with col4:

                st.write("")

                if st.button(
                    "🗑️",
                    key=f"remove_warehouse_{index}",
                ):

                    if len(
                        st.session_state.warehouse_blocks
                    ) > 1:

                        st.session_state.warehouse_blocks.pop(
                            index
                        )

                        st.rerun()

    if st.button(
        "➕ Add Warehouse Candidate",
    ):

        st.session_state.warehouse_blocks.append(
            {
                "location": None,
                "capacity": 1000,
                "fixed_cost": 5000,
            }
        )

        st.rerun()


st.divider()


# ============================================================
# RUN OPTIMIZATION
# ============================================================

st.header("3. Run Optimization")

run_col1, run_col2 = st.columns([4, 1])

with run_col1:

    st.write(
        "GRIDPOINT will assign every selected neighborhood to a warehouse "
        "while minimizing logistics cost."
    )

with run_col2:

    optimize_clicked = st.button(
        "🚀 Optimize",
        type="primary",
        use_container_width=True,
    )


if optimize_clicked:

    if customers_df.empty:

        st.error(
            "Please add at least one valid customer neighborhood."
        )

    elif warehouse_mode == "Manual":

        warehouses_df = make_warehouse_dataframe(
            st.session_state.warehouse_blocks
        )

        if warehouses_df.empty:

            st.error(
                "Please add at least one valid warehouse."
            )

            warehouses_df = None

    else:

        warehouses_df = generate_warehouse_candidates(
            customers_df,
            count=max(8, int(num_warehouses) + 5),
        )

    if warehouses_df is not None and not warehouses_df.empty:

        try:

            with st.spinner(
                "Running warehouse optimization..."
            ):

                result = optimize_warehouses(
                    customers_df,
                    warehouses_df,
                    max_warehouses=int(num_warehouses),
                    cost_per_km=float(cost_per_km),
                    max_delivery_radius=max_delivery_radius,
                )

            st.session_state.optimization_result = result

            st.session_state.optimization_inputs = {
                "customers": customers_df.copy(),
                "warehouses": warehouses_df.copy(),
                "num_warehouses": int(num_warehouses),
                "cost_per_km": float(cost_per_km),
                "radius": max_delivery_radius,
            }

        except Exception as error:

            st.error(
                f"Optimization failed: {error}"
            )

            st.session_state.optimization_result = None


# ============================================================
# RESULTS
# ============================================================

result = st.session_state.optimization_result
optimization_inputs = st.session_state.optimization_inputs


if result is not None:

    st.divider()

    st.header("4. Optimization Results")

    status = result.get("status", "UNKNOWN")

    if str(status).upper() in [
        "OPTIMAL",
        "FEASIBLE",
        "OPTIMAL_SOLUTION_FOUND",
    ]:

        st.success(
            f"Optimization status: {status}"
        )

    else:

        st.error(
            f"Optimization status: {status}"
        )

        message = result.get("message")

        if message:
            st.write(message)


    # --------------------------------------------------------
    # METRICS
    # --------------------------------------------------------

    metrics = result.get("metrics", {})

    if not isinstance(metrics, dict):
        metrics = {}


    total_cost = metrics.get(
        "total_cost",
        result.get("objective"),
    )

    delivery_cost = metrics.get(
        "delivery_cost"
    )

    fixed_cost = metrics.get(
        "fixed_cost"
    )

    average_distance = metrics.get(
        "average_distance"
    )

    weighted_average_distance = metrics.get(
        "weighted_average_distance"
    )

    total_orders = metrics.get(
        "total_orders"
    )

    cost_savings = metrics.get(
        "cost_savings"
    )

    cost_savings_percent = metrics.get(
        "cost_savings_percent"
    )


    metric1, metric2, metric3, metric4 = st.columns(4)

    with metric1:

        st.metric(
            "Total Cost",
            format_currency(total_cost),
        )

    with metric2:

        st.metric(
            "Delivery Cost",
            format_currency(delivery_cost),
        )

    with metric3:

        st.metric(
            "Average Distance",
            format_distance(average_distance),
        )

    with metric4:

        if cost_savings_percent is not None:

            savings_display = (
                f"{safe_number(cost_savings_percent):.1f}%"
            )

        elif cost_savings is not None:

            savings_display = format_currency(
                cost_savings
            )

        else:

            savings_display = "—"

        st.metric(
            "Cost Savings",
            savings_display,
        )


    # --------------------------------------------------------
    # ADDITIONAL KPI ROW
    # --------------------------------------------------------

    st.write("")

    kpi1, kpi2, kpi3, kpi4 = st.columns(4)

    with kpi1:

        st.metric(
            "Orders",
            f"{int(safe_number(total_orders)):,}"
            if total_orders is not None
            else "—",
        )

    with kpi2:

        st.metric(
            "Weighted Distance",
            format_distance(
                weighted_average_distance
            ),
        )

    with kpi3:

        st.metric(
            "Fixed Cost",
            format_currency(fixed_cost),
        )

    with kpi4:

        opened = result.get(
            "opened_warehouses",
            [],
        )

        if isinstance(opened, (list, tuple, set)):
            opened_count = len(opened)
        else:
            opened_count = 0

        st.metric(
            "Warehouses Opened",
            str(opened_count),
        )


    st.divider()


    # --------------------------------------------------------
    # OPENED WAREHOUSES
    # --------------------------------------------------------

    st.subheader("🏭 Selected Warehouses")

    opened = result.get(
        "opened_warehouses",
        [],
    )

    warehouses_df = (
        optimization_inputs.get("warehouses")
        if optimization_inputs
        else pd.DataFrame()
    )

    if warehouses_df is None:
        warehouses_df = pd.DataFrame()


    opened_rows = []

    if isinstance(opened, dict):

        opened_ids = list(opened.keys())

    elif isinstance(opened, (list, tuple, set)):

        opened_ids = list(opened)

    else:

        opened_ids = []


    for warehouse_id in opened_ids:

        row = None

        # Search by id
        if "id" in warehouses_df.columns:

            matches = warehouses_df[
                warehouses_df["id"].astype(str)
                == str(warehouse_id)
            ]

            if not matches.empty:
                row = matches.iloc[0]

        # Search by name
        if row is None and "name" in warehouses_df.columns:

            matches = warehouses_df[
                warehouses_df["name"].astype(str)
                == str(warehouse_id)
            ]

            if not matches.empty:
                row = matches.iloc[0]

        if row is not None:

            opened_rows.append(
                {
                    "Warehouse": row.get(
                        "name",
                        str(warehouse_id),
                    ),
                    "Capacity": row.get(
                        "capacity",
                        "—",
                    ),
                    "Fixed Cost": row.get(
                        "fixed_cost",
                        "—",
                    ),
                    "Latitude": row.get(
                        "latitude",
                        "—",
                    ),
                    "Longitude": row.get(
                        "longitude",
                        "—",
                    ),
                }
            )

        else:

            opened_rows.append(
                {
                    "Warehouse": str(warehouse_id),
                    "Capacity": "—",
                    "Fixed Cost": "—",
                    "Latitude": "—",
                    "Longitude": "—",
                }
            )


    if opened_rows:

        opened_df = pd.DataFrame(opened_rows)

        st.dataframe(
            opened_df,
            use_container_width=True,
            hide_index=True,
        )

    else:

        st.info(
            "No warehouse details were returned by the optimizer."
        )


    st.divider()


    # --------------------------------------------------------
    # UTILIZATION
    # --------------------------------------------------------

    st.subheader("📦 Warehouse Utilization")

    utilization = result.get(
        "utilization"
    )

    utilization_df = normalize_utilization(
        utilization
    )


    if not utilization_df.empty:

        display_columns = [
            column
            for column in [
                "Warehouse",
                "Assigned Orders",
                "Capacity",
                "Remaining Capacity",
                "Utilization",
            ]
            if column in utilization_df.columns
        ]

        utilization_display = utilization_df[
            display_columns
        ].copy()


        if "Utilization" in utilization_display.columns:

            def normalize_utilization_value(value):

                number = safe_number(
                    value,
                    None,
                )

                if number is None:
                    return None

                if number <= 1:
                    return number * 100

                return number


            utilization_display[
                "Utilization"
            ] = utilization_display[
                "Utilization"
            ].apply(
                normalize_utilization_value
            )

            utilization_display[
                "Utilization"
            ] = utilization_display[
                "Utilization"
            ].round(1)


        st.dataframe(
            utilization_display,
            use_container_width=True,
            hide_index=True,
        )


        if (
            "Warehouse"
            in utilization_display.columns
            and
            "Assigned Orders"
            in utilization_display.columns
            and
            "Capacity"
            in utilization_display.columns
        ):

            chart_df = utilization_display[
                [
                    "Warehouse",
                    "Assigned Orders",
                    "Capacity",
                ]
            ].copy()

            chart_df = chart_df.set_index(
                "Warehouse"
            )

            st.bar_chart(
                chart_df
            )

    else:

        st.info(
            "Utilization information was not returned by the optimizer."
        )


    st.divider()


    # --------------------------------------------------------
    # CUSTOMER ASSIGNMENTS
    # --------------------------------------------------------

    st.subheader("🚚 Customer Assignments")

    assignments = result.get(
        "assignments"
    )

    assignments_df = normalize_assignments(
        assignments
    )

    if not assignments_df.empty:

        st.dataframe(
            assignments_df,
            use_container_width=True,
            hide_index=True,
        )

        csv_data = assignments_df.to_csv(
            index=False
        ).encode("utf-8")

        st.download_button(
            "⬇️ Download Assignments CSV",
            data=csv_data,
            file_name="gridpoint_assignments.csv",
            mime="text/csv",
        )

    else:

        st.info(
            "No assignment table was returned."
        )


    st.divider()


    # --------------------------------------------------------
    # MAP
    # --------------------------------------------------------

    st.subheader("🗺️ Logistics Network")

    customers_for_map = (
        optimization_inputs.get("customers")
        if optimization_inputs
        else pd.DataFrame()
    )

    warehouses_for_map = (
        optimization_inputs.get("warehouses")
        if optimization_inputs
        else pd.DataFrame()
    )


    if (
        customers_for_map is not None
        and not customers_for_map.empty
        and warehouses_for_map is not None
        and not warehouses_for_map.empty
    ):

        center_lat = customers_for_map[
            "latitude"
        ].mean()

        center_lon = customers_for_map[
            "longitude"
        ].mean()


        fmap = folium.Map(
            location=[
                center_lat,
                center_lon,
            ],
            zoom_start=11,
            tiles="OpenStreetMap",
        )


        # ----------------------------------------------------
        # Customer markers
        # ----------------------------------------------------

        for _, customer in customers_for_map.iterrows():

            folium.Marker(
                location=[
                    float(customer["latitude"]),
                    float(customer["longitude"]),
                ],
                popup=(
                    f"<b>{customer['name']}</b><br>"
                    f"Orders: {customer['orders']}"
                ),
                tooltip=customer["name"],
                icon=folium.Icon(
                    icon="shopping-cart",
                    prefix="fa",
                ),
            ).add_to(fmap)


        # ----------------------------------------------------
        # Warehouse markers
        # ----------------------------------------------------

        for _, warehouse in warehouses_for_map.iterrows():

            warehouse_id = warehouse.get(
                "id",
                warehouse.get(
                    "name",
                    "",
                ),
            )

            is_open = (
                warehouse_id in opened_ids
                or warehouse.get("name") in opened_ids
            )

            if is_open:

                folium.Marker(
                    location=[
                        float(
                            warehouse["latitude"]
                        ),
                        float(
                            warehouse["longitude"]
                        ),
                    ],
                    popup=(
                        f"<b>{warehouse.get('name', warehouse_id)}</b><br>"
                        f"Capacity: "
                        f"{warehouse.get('capacity', '—')}"
                    ),
                    tooltip=(
                        f"Selected Warehouse: "
                        f"{warehouse.get('name', warehouse_id)}"
                    ),
                    icon=folium.Icon(
                        color="red",
                        icon="home",
                        prefix="fa",
                    ),
                ).add_to(fmap)


        # ----------------------------------------------------
        # Assignment route lines
        # ----------------------------------------------------

        assignment_rows = []

        if isinstance(assignments, list):

            assignment_rows = assignments

        elif isinstance(assignments, dict):

            for customer, warehouse in assignments.items():

                if isinstance(warehouse, dict):

                    row = dict(warehouse)
                    row["Customer"] = customer

                else:

                    row = {
                        "Customer": customer,
                        "Warehouse": warehouse,
                    }

                assignment_rows.append(row)


        for assignment in assignment_rows:

            if not isinstance(assignment, dict):
                continue

            customer_name = (
                assignment.get("Customer")
                or assignment.get("customer")
                or assignment.get("customer_id")
                or assignment.get("neighborhood")
            )

            warehouse_name = (
                assignment.get("Warehouse")
                or assignment.get("warehouse")
                or assignment.get("warehouse_id")
            )

            if not customer_name or not warehouse_name:
                continue


            customer_match = customers_for_map[
                customers_for_map["name"].astype(str)
                == str(customer_name)
            ]

            if customer_match.empty:

                customer_match = customers_for_map[
                    customers_for_map["id"].astype(str)
                    == str(customer_name)
                ]


            warehouse_match = warehouses_for_map[
                warehouses_for_map["name"].astype(str)
                == str(warehouse_name)
            ]

            if warehouse_match.empty and "id" in warehouses_for_map.columns:

                warehouse_match = warehouses_for_map[
                    warehouses_for_map["id"].astype(str)
                    == str(warehouse_name)
                ]


            if (
                customer_match.empty
                or warehouse_match.empty
            ):
                continue


            customer = customer_match.iloc[0]
            warehouse = warehouse_match.iloc[0]


            folium.PolyLine(
                locations=[
                    [
                        float(customer["latitude"]),
                        float(customer["longitude"]),
                    ],
                    [
                        float(warehouse["latitude"]),
                        float(warehouse["longitude"]),
                    ],
                ],
                weight=2,
                opacity=0.6,
            ).add_to(fmap)


        st_folium(
            fmap,
            width=None,
            height=600,
            returned_objects=[],
        )


    else:

        st.info(
            "Map will appear after successful optimization."
        )


    st.divider()


    # --------------------------------------------------------
    # BEFORE VS AFTER
    # --------------------------------------------------------

    st.subheader("📈 Optimization Impact")

    baseline_cost = metrics.get(
        "baseline_delivery_cost"
    )

    baseline_distance = metrics.get(
        "baseline_average_distance"
    )


    if (
        baseline_cost is not None
        or baseline_distance is not None
    ):

        impact1, impact2 = st.columns(2)

        with impact1:

            st.metric(
                "Baseline Delivery Cost",
                format_currency(
                    baseline_cost
                ),
            )

        with impact2:

            st.metric(
                "Baseline Average Distance",
                format_distance(
                    baseline_distance
                ),
            )

    else:

        st.info(
            "Baseline comparison will be shown when the optimizer "
            "returns baseline metrics."
        )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "GRIDPOINT • Intelligent Warehouse Location Optimization"
)