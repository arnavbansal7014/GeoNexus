import pandas as pd
import numpy as np
import pulp


# ============================================================
# DISTANCE CALCULATION
# ============================================================

def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Calculate geographical distance between two coordinates
    using the Haversine formula.

    Returns:
        Distance in kilometers.
    """

    R = 6371.0

    lat1 = np.radians(lat1)
    lat2 = np.radians(lat2)

    dlat = lat2 - lat1
    dlon = np.radians(lon2) - np.radians(lon1)

    a = (
        np.sin(dlat / 2) ** 2
        +
        np.cos(lat1)
        * np.cos(lat2)
        * np.sin(dlon / 2) ** 2
    )

    # Protect against floating-point errors
    a = np.clip(a, 0, 1)

    c = 2 * np.arctan2(
        np.sqrt(a),
        np.sqrt(1 - a)
    )

    return R * c


# ============================================================
# DATA VALIDATION
# ============================================================

def validate_data(neighborhoods, warehouses):
    """
    Validate input datasets before optimization.
    """

    neighborhood_columns = [
        "id",
        "name",
        "latitude",
        "longitude",
        "orders"
    ]

    warehouse_columns = [
        "id",
        "name",
        "latitude",
        "longitude",
        "capacity",
        "fixed_cost"
    ]

    missing_neighborhoods = [
        column
        for column in neighborhood_columns
        if column not in neighborhoods.columns
    ]

    missing_warehouses = [
        column
        for column in warehouse_columns
        if column not in warehouses.columns
    ]

    if missing_neighborhoods:

        raise ValueError(
            "Missing columns in neighborhoods.csv: "
            + ", ".join(missing_neighborhoods)
        )

    if missing_warehouses:

        raise ValueError(
            "Missing columns in warehouses.csv: "
            + ", ".join(missing_warehouses)
        )

    if neighborhoods.empty:

        raise ValueError(
            "Neighborhood dataset is empty."
        )

    if warehouses.empty:

        raise ValueError(
            "Warehouse dataset is empty."
        )

    if (neighborhoods["orders"] < 0).any():

        raise ValueError(
            "Orders cannot be negative."
        )

    if (warehouses["capacity"] <= 0).any():

        raise ValueError(
            "Warehouse capacity must be greater than zero."
        )

    if (warehouses["fixed_cost"] < 0).any():

        raise ValueError(
            "Warehouse fixed cost cannot be negative."
        )


# ============================================================
# DISTANCE MATRIX
# ============================================================

def build_distance_matrix(neighborhoods, warehouses):
    """
    Create a matrix containing the distance from every
    neighborhood to every candidate warehouse.

    Returns:
        Dictionary:
        (neighborhood_id, warehouse_id) -> distance_km
    """

    distances = {}

    for _, neighborhood in neighborhoods.iterrows():

        for _, warehouse in warehouses.iterrows():

            distance = calculate_distance(
                neighborhood["latitude"],
                neighborhood["longitude"],
                warehouse["latitude"],
                warehouse["longitude"]
            )

            distances[
                (
                    neighborhood["id"],
                    warehouse["id"]
                )
            ] = distance

    return distances


# ============================================================
# MAIN OPTIMIZATION FUNCTION
# ============================================================

def optimize_warehouses(
    neighborhoods,
    warehouses,
    max_warehouses=2,
    cost_per_km=10,
    max_delivery_radius=None
):
    """
    Optimize warehouse locations and neighborhood assignments.

    Parameters
    ----------
    neighborhoods : DataFrame
        Neighborhood information.

    warehouses : DataFrame
        Candidate warehouse information.

    max_warehouses : int
        Maximum number of warehouses that can be opened.

    cost_per_km : float
        Delivery cost per order per kilometer.

    max_delivery_radius : float or None
        Maximum allowed distance between a neighborhood
        and its assigned warehouse.

    Returns
    -------
    dict
        Optimization results.
    """

    # ========================================================
    # VALIDATION
    # ========================================================

    validate_data(
        neighborhoods,
        warehouses
    )

    if max_warehouses < 1:

        raise ValueError(
            "max_warehouses must be at least 1."
        )

    if max_warehouses > len(warehouses):

        max_warehouses = len(warehouses)

    if cost_per_km < 0:

        raise ValueError(
            "cost_per_km cannot be negative."
        )

    if max_delivery_radius is not None:

        if max_delivery_radius <= 0:

            raise ValueError(
                "max_delivery_radius must be greater than zero."
            )


    # ========================================================
    # CREATE OPTIMIZATION MODEL
    # ========================================================

    problem = pulp.LpProblem(
        "GRIDPOINT_Warehouse_Optimization",
        pulp.LpMinimize
    )


    # ========================================================
    # DISTANCES
    # ========================================================

    distances = build_distance_matrix(
        neighborhoods,
        warehouses
    )


    # ========================================================
    # DECISION VARIABLES
    # ========================================================

    # --------------------------------------------------------
    # y[j]
    #
    # 1 = warehouse is opened
    # 0 = warehouse is closed
    # --------------------------------------------------------

    warehouse_open = {

        warehouse_id:
            pulp.LpVariable(
                f"open_{warehouse_id}",
                cat="Binary"
            )

        for warehouse_id
        in warehouses["id"]
    }


    # --------------------------------------------------------
    # x[i,j]
    #
    # 1 = neighborhood i assigned to warehouse j
    # 0 = otherwise
    # --------------------------------------------------------

    assignment = {

        (
            neighborhood_id,
            warehouse_id
        ):
            pulp.LpVariable(
                f"assign_{neighborhood_id}_{warehouse_id}",
                cat="Binary"
            )

        for neighborhood_id
        in neighborhoods["id"]

        for warehouse_id
        in warehouses["id"]
    }


    # ========================================================
    # OBJECTIVE FUNCTION
    # ========================================================

    delivery_cost_terms = []

    fixed_cost_terms = []


    # --------------------------------------------------------
    # Delivery cost
    #
    # orders × distance × cost_per_km
    # --------------------------------------------------------

    for _, neighborhood in neighborhoods.iterrows():

        for _, warehouse in warehouses.iterrows():

            neighborhood_id = neighborhood["id"]
            warehouse_id = warehouse["id"]

            distance = distances[
                (
                    neighborhood_id,
                    warehouse_id
                )
            ]

            delivery_cost = (
                neighborhood["orders"]
                * distance
                * cost_per_km
            )

            delivery_cost_terms.append(
                delivery_cost
                * assignment[
                    (
                        neighborhood_id,
                        warehouse_id
                    )
                ]
            )


    # --------------------------------------------------------
    # Fixed warehouse opening cost
    # --------------------------------------------------------

    for _, warehouse in warehouses.iterrows():

        warehouse_id = warehouse["id"]

        fixed_cost_terms.append(
            warehouse["fixed_cost"]
            * warehouse_open[
                warehouse_id
            ]
        )


    # --------------------------------------------------------
    # Minimize:
    #
    # Delivery Cost + Warehouse Fixed Cost
    # --------------------------------------------------------

    problem += (
        pulp.lpSum(delivery_cost_terms)
        +
        pulp.lpSum(fixed_cost_terms)
    )


    # ========================================================
    # CONSTRAINT 1
    # EVERY NEIGHBORHOOD MUST BE ASSIGNED ONCE
    # ========================================================

    for _, neighborhood in neighborhoods.iterrows():

        neighborhood_id = neighborhood["id"]

        problem += (
            pulp.lpSum(
                assignment[
                    (
                        neighborhood_id,
                        warehouse_id
                    )
                ]

                for warehouse_id
                in warehouses["id"]

            )
            == 1,

            f"OneWarehouse_{neighborhood_id}"
        )


    # ========================================================
    # CONSTRAINT 2
    # ASSIGNMENT ONLY TO OPEN WAREHOUSE
    # ========================================================

    for _, neighborhood in neighborhoods.iterrows():

        neighborhood_id = neighborhood["id"]

        for warehouse_id in warehouses["id"]:

            problem += (

                assignment[
                    (
                        neighborhood_id,
                        warehouse_id
                    )
                ]

                <=

                warehouse_open[
                    warehouse_id
                ],

                f"OpenWarehouseRequired_"
                f"{neighborhood_id}_"
                f"{warehouse_id}"
            )


    # ========================================================
    # CONSTRAINT 3
    # WAREHOUSE CAPACITY
    # ========================================================

    for _, warehouse in warehouses.iterrows():

        warehouse_id = warehouse["id"]

        capacity = warehouse["capacity"]

        problem += (

            pulp.lpSum(

                neighborhood["orders"]
                *
                assignment[
                    (
                        neighborhood["id"],
                        warehouse_id
                    )
                ]

                for _, neighborhood
                in neighborhoods.iterrows()

            )

            <=

            capacity
            *
            warehouse_open[
                warehouse_id
            ],

            f"Capacity_{warehouse_id}"
        )


    # ========================================================
    # CONSTRAINT 4
    # MAXIMUM NUMBER OF WAREHOUSES
    # ========================================================

    problem += (

        pulp.lpSum(
            warehouse_open[
                warehouse_id
            ]

            for warehouse_id
            in warehouses["id"]
        )

        <=

        max_warehouses,

        "MaximumWarehouses"
    )


    # ========================================================
    # CONSTRAINT 5
    # MAXIMUM DELIVERY RADIUS
    # ========================================================

    if max_delivery_radius is not None:

        for _, neighborhood in neighborhoods.iterrows():

            neighborhood_id = neighborhood["id"]

            for warehouse_id in warehouses["id"]:

                distance = distances[
                    (
                        neighborhood_id,
                        warehouse_id
                    )
                ]

                if distance > max_delivery_radius:

                    problem += (

                        assignment[
                            (
                                neighborhood_id,
                                warehouse_id
                            )
                        ]

                        == 0,

                        f"MaximumRadius_"
                        f"{neighborhood_id}_"
                        f"{warehouse_id}"
                    )


    # ========================================================
    # SOLVE
    # ========================================================

    solver = pulp.PULP_CBC_CMD(
        msg=False
    )

    problem.solve(
        solver
    )


    # ========================================================
    # SOLUTION STATUS
    # ========================================================

    status = pulp.LpStatus[
        problem.status
    ]


    # --------------------------------------------------------
    # Infeasible / failed solution
    # --------------------------------------------------------

    if status != "Optimal":

        return {

            "status": status,

            "objective": None,

            "opened_warehouses": [],

            "assignments": pd.DataFrame(),

            "metrics": {},

            "message": (
                "GRIDPOINT could not find an optimal "
                "solution under the current constraints."
            )
        }


    # ========================================================
    # SELECTED WAREHOUSES
    # ========================================================

    opened_warehouses = []

    for warehouse_id in warehouses["id"]:

        value = pulp.value(
            warehouse_open[
                warehouse_id
            ]
        )

        if value is not None and value > 0.5:

            opened_warehouses.append(
                warehouse_id
            )


    # ========================================================
    # BUILD ASSIGNMENT RESULTS
    # ========================================================

    results = []


    for _, neighborhood in neighborhoods.iterrows():

        neighborhood_id = neighborhood["id"]

        for _, warehouse in warehouses.iterrows():

            warehouse_id = warehouse["id"]

            value = pulp.value(
                assignment[
                    (
                        neighborhood_id,
                        warehouse_id
                    )
                ]
            )

            if value is not None and value > 0.5:

                distance = distances[
                    (
                        neighborhood_id,
                        warehouse_id
                    )
                ]

                delivery_cost = (
                    neighborhood["orders"]
                    *
                    distance
                    *
                    cost_per_km
                )

                results.append({

                    "neighborhood":
                        neighborhood["name"],

                    "neighborhood_id":
                        neighborhood_id,

                    "warehouse":
                        warehouse["name"],

                    "warehouse_id":
                        warehouse_id,

                    "orders":
                        neighborhood["orders"],

                    "distance_km":
                        round(
                            distance,
                            2
                        ),

                    "delivery_cost":
                        round(
                            delivery_cost,
                            2
                        )
                })


    assignments_df = pd.DataFrame(
        results
    )


    # ========================================================
    # COST METRICS
    # ========================================================

    total_delivery_cost = (
        assignments_df[
            "delivery_cost"
        ].sum()
    )


    total_fixed_cost = sum(

        warehouse["fixed_cost"]

        for _, warehouse
        in warehouses.iterrows()

        if warehouse["id"]
        in opened_warehouses
    )


    total_cost = (
        total_delivery_cost
        +
        total_fixed_cost
    )


    # ========================================================
    # DISTANCE METRICS
    # ========================================================

    total_orders = (
        assignments_df[
            "orders"
        ].sum()
    )


    average_distance = (
        assignments_df[
            "distance_km"
        ].mean()
    )


    if total_orders > 0:

        weighted_average_distance = (

            (
                assignments_df[
                    "distance_km"
                ]
                *
                assignments_df[
                    "orders"
                ]
            ).sum()

            /

            total_orders
        )

    else:

        weighted_average_distance = 0


    # ========================================================
    # WAREHOUSE UTILIZATION
    # ========================================================

    utilization = []


    for _, warehouse in warehouses.iterrows():

        warehouse_id = warehouse["id"]

        assigned_orders = assignments_df.loc[

            assignments_df[
                "warehouse_id"
            ]
            == warehouse_id,

            "orders"

        ].sum()


        capacity = warehouse[
            "capacity"
        ]


        utilization_percent = (

            assigned_orders
            /
            capacity
            *
            100
        )


        utilization.append({

            "warehouse_id":
                warehouse_id,

            "warehouse":
                warehouse["name"],

            "assigned_orders":
                assigned_orders,

            "capacity":
                capacity,

            "remaining_capacity":
                capacity - assigned_orders,

            "utilization_percent":
                round(
                    utilization_percent,
                    2
                )
        })


    utilization_df = pd.DataFrame(
        utilization
    )


    # ========================================================
    # BASELINE
    # ========================================================

    # Baseline = every neighborhood assigned to the
    # nearest candidate warehouse without considering
    # warehouse opening optimization.

    baseline_delivery_cost = 0

    baseline_distances = []


    for _, neighborhood in neighborhoods.iterrows():

        neighborhood_id = neighborhood["id"]

        available_distances = []

        for warehouse_id in warehouses["id"]:

            distance = distances[
                (
                    neighborhood_id,
                    warehouse_id
                )
            ]

            available_distances.append(
                (
                    distance,
                    warehouse_id
                )
            )


        nearest_distance, nearest_warehouse = min(
            available_distances,
            key=lambda x: x[0]
        )


        baseline_distances.append(
            nearest_distance
        )


        baseline_delivery_cost += (

            neighborhood["orders"]
            *
            nearest_distance
            *
            cost_per_km
        )


    baseline_average_distance = np.mean(
        baseline_distances
    )


    # ========================================================
    # COST SAVINGS
    # ========================================================

    cost_savings = (
        baseline_delivery_cost
        -
        total_delivery_cost
    )


    if baseline_delivery_cost > 0:

        cost_savings_percent = (

            cost_savings
            /
            baseline_delivery_cost
            *
            100
        )

    else:

        cost_savings_percent = 0


    # ========================================================
    # FINAL RESULTS
    # ========================================================

    return {

        "status":
            status,

        "objective":
            round(
                total_cost,
                2
            ),

        "opened_warehouses":
            opened_warehouses,

        "assignments":
            assignments_df,

        "utilization":
            utilization_df,

        "metrics": {

            "total_cost":
                round(
                    total_cost,
                    2
                ),

            "delivery_cost":
                round(
                    total_delivery_cost,
                    2
                ),

            "fixed_cost":
                round(
                    total_fixed_cost,
                    2
                ),

            "total_orders":
                int(
                    total_orders
                ),

            "average_distance":
                round(
                    average_distance,
                    2
                ),

            "weighted_average_distance":
                round(
                    weighted_average_distance,
                    2
                ),

            "baseline_delivery_cost":
                round(
                    baseline_delivery_cost,
                    2
                ),

            "baseline_average_distance":
                round(
                    baseline_average_distance,
                    2
                ),

            "cost_savings":
                round(
                    cost_savings,
                    2
                ),

            "cost_savings_percent":
                round(
                    cost_savings_percent,
                    2
                )
        },

        "message":
            "Optimal warehouse configuration found."
    }