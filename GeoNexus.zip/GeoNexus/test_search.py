import streamlit as st

PLACES = [
    ("Koramangala, Bengaluru", 12.9352, 77.6245),
    ("Koramangala 1st Block, Bengaluru", 12.9345, 77.6205),
    ("Koramangala 2nd Block, Bengaluru", 12.9285, 77.6250),
    ("Jayanagar, Bengaluru", 12.9293, 77.5824),
    ("Jayanagar 4th Block, Bengaluru", 12.9266, 77.5835),
    ("JP Nagar, Bengaluru", 12.9118, 77.5976),
    ("JP Nagar 1st Phase, Bengaluru", 12.9119, 77.5799),
    ("JP Nagar 2nd Phase, Bengaluru", 12.9117, 77.5918),
    ("Indiranagar, Bengaluru", 12.9784, 77.6408),
    ("Whitefield, Bengaluru", 12.9698, 77.7499),
    ("HSR Layout, Bengaluru", 12.9116, 77.6474),
    ("BTM Layout, Bengaluru", 12.9166, 77.6101),
]

st.title("GRIDPOINT Location Search Test")

query = st.text_input(
    "Search Bengaluru",
    placeholder="Type kora, jaya, jp, white..."
)

if query:

    q = query.strip().lower()

    matches = [
        place for place in PLACES
        if q in place[0].lower()
    ]

    if matches:

        st.write("### Suggestions")

        for name, lat, lon in matches:

            if st.button(
                f"📍 {name}",
                key=name
            ):

                st.success(
                    f"Selected: {name}"
                )

                st.write(
                    f"Latitude: {lat}"
                )

                st.write(
                    f"Longitude: {lon}"
                )

    else:

        st.warning(
            "No matching location found."
        )