"""
GEONEXUS visual theme
======================

Everything visual lives here so app.py can stay focused on logic.

Design language
---------------
  * Survey-map paper background with a faint grid (the "grid" in GEONEXUS).
  * Circles mean demand (neighborhoods). Squares mean supply (warehouses).
  * Every opened warehouse gets a colour. Its customers, delivery lines and
    utilisation bar share that colour, so the colour carries information.
  * Motion is used in four places only: the hero, the solving loader, the
    capacity bars and the map's delivery lines.
"""

import html as _html

import numpy as np
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components


# ------------------------------------------------------------------
# TOKENS
# ------------------------------------------------------------------

INK = "#0F2A43"
MARIGOLD = "#F4A300"
TEAL = "#0B7A75"
DEMAND = "#3C5A75"
CLOSED = "#8A9BAA"

# One colour per opened warehouse (cycles after six).
WAREHOUSE_COLORS = [
    "#F4A300",  # marigold
    "#0B7A75",  # teal
    "#4B57D6",  # indigo
    "#C2417A",  # rose
    "#5E8C1F",  # leaf
    "#D9482B",  # vermilion
]


def warehouse_color(index):
    return WAREHOUSE_COLORS[index % len(WAREHOUSE_COLORS)]


# ------------------------------------------------------------------
# SMALL HELPERS
# ------------------------------------------------------------------

def esc(value):
    return _html.escape(str(value), quote=True)


def _compact(markup):
    """
    Collapse markup onto one line. Markdown treats blank lines and
    4-space indents inside HTML as code blocks, so we avoid both.
    """
    return " ".join(
        line.strip()
        for line in markup.strip().splitlines()
        if line.strip()
    )


def html_block(markup):
    st.markdown(_compact(markup), unsafe_allow_html=True)


def money(value, decimals=2):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "n/a"
    sign = "-" if number < 0 else ""
    return f"{sign}₹{abs(number):,.{decimals}f}"


def keyed_container(key, border=False):
    """
    Containers with a key get a `st-key-<key>` CSS class, which lets the
    theme style them. Older Streamlit versions ignore the key argument.
    """
    try:
        return st.container(border=border, key=key)
    except TypeError:
        return st.container(border=border)


def favicon():
    """A marigold square and a teal circle on ink. Falls back to an emoji."""
    try:
        from PIL import Image, ImageDraw

        size = 128
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.rounded_rectangle(
            (0, 0, size - 1, size - 1), radius=30, fill=INK
        )
        draw.rectangle((26, 52, 82, 108), fill=MARIGOLD)
        draw.ellipse((62, 18, 112, 68), fill=TEAL, outline=INK, width=5)
        return img
    except Exception:
        return "📍"


# ------------------------------------------------------------------
# GLOBAL CSS
# ------------------------------------------------------------------

CSS = """
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Instrument+Sans:wght@400..700&display=swap');

:root {
    --paper: #E8EEF2;
    --panel: #FBFDFE;
    --ink: #0F2A43;
    --muted: #4F6275;
    --line: #C8D4DD;
    --line-soft: #DCE5EB;
    --marigold: #F4A300;
    --teal: #0B7A75;
    --demand: #3C5A75;
    --font-display: 'Bricolage Grotesque', 'Segoe UI', system-ui, sans-serif;
    --font-body: 'Instrument Sans', 'Segoe UI', system-ui, sans-serif;
}

/* ---------- page ---------- */

body .stApp {
    background-color: var(--paper);
    background-image:
        linear-gradient(rgba(15, 42, 67, .05) 1px, transparent 1px),
        linear-gradient(90deg, rgba(15, 42, 67, .05) 1px, transparent 1px);
    background-size: 48px 48px;
    font-family: var(--font-body);
    color: var(--ink);
}

[data-testid="stAppViewContainer"],
[data-testid="stMain"],
section.main {
    background: transparent;
}

[data-testid="stHeader"] { background: transparent; }
[data-testid="stDecoration"], footer { display: none; }

[data-testid="stMainBlockContainer"],
.block-container {
    max-width: 1240px;
    padding: 1.25rem 2rem 4rem;
}

@media (max-width: 640px) {
    [data-testid="stMainBlockContainer"],
    .block-container { padding: 1rem 1rem 3rem; }
}

/* style-only blocks should not leave a gap */
.element-container:has(style),
[data-testid="stElementContainer"]:has(style) { display: none; }

/* ---------- type ---------- */

body .stApp h1,
body .stApp h2,
body .stApp h3,
body .stApp h4 {
    font-family: var(--font-display);
    color: var(--ink);
    letter-spacing: -.015em;
}

body .stApp p,
body .stApp label,
body .stApp li,
body .stApp input,
body .stApp textarea,
body .stApp button {
    font-family: var(--font-body);
}

body .stApp [data-testid="stCaptionContainer"] {
    color: var(--muted);
    font-size: 14px;
}

/* ---------- hero ---------- */

.st-key-hero { margin-bottom: .25rem; }

.st-key-hero iframe {
    display: block;
    width: 100%;
    border: 1px solid var(--line);
    border-radius: 22px;
    box-shadow: 0 18px 40px -24px rgba(15, 42, 67, .35);
}

/* ---------- step headings ---------- */

.gp-step {
    display: flex;
    gap: 16px;
    align-items: flex-start;
    margin: 46px 0 18px;
}

.gp-step-n {
    flex: none;
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: var(--ink);
    color: var(--marigold);
    font: 700 19px/38px var(--font-display);
    text-align: center;
}

.gp-step-title {
    margin: 0;
    padding: 0;
    font: 700 30px/1.08 var(--font-display);
    letter-spacing: -.02em;
    color: var(--ink);
}

.gp-step-sub {
    margin: 6px 0 0;
    max-width: 62ch;
    font-size: 15px;
    line-height: 1.5;
    color: var(--muted);
}

.gp-sub {
    margin: 34px 0 12px;
    font: 700 21px/1.15 var(--font-display);
    letter-spacing: -.015em;
    color: var(--ink);
}

.gp-sub small {
    display: block;
    margin-top: 4px;
    font: 400 14px/1.45 var(--font-body);
    letter-spacing: 0;
    color: var(--muted);
}

/* ---------- field labels ---------- */

.gp-label {
    display: flex;
    align-items: center;
    gap: 9px;
    margin: 0 0 6px;
    font: 600 14px/1.2 var(--font-body);
    color: var(--ink);
}

.gp-mark {
    flex: none;
    width: 13px;
    height: 13px;
    box-sizing: border-box;
}

.gp-mark.demand { border-radius: 50%; background: var(--demand); }

.gp-mark.supply {
    border-radius: 2px;
    background: var(--marigold);
    border: 2px solid var(--ink);
}

/* ---------- input rows ---------- */

body .stApp [class*="st-key-nbh_row_"],
body .stApp [class*="st-key-wh_row_"] {
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 14px;
    padding: 16px 18px;
    box-shadow: 0 1px 0 rgba(15, 42, 67, .04);
}

body .stApp [data-baseweb="input"],
body .stApp [data-baseweb="base-input"] { border-radius: 10px; }

body .stApp [data-testid="stNumberInput"] [data-baseweb="input"] {
    border: 1px solid var(--line);
    background: #fff;
}

body .stApp [data-testid="stNumberInput"] [data-baseweb="input"]:focus-within {
    border-color: var(--teal);
    box-shadow: 0 0 0 3px rgba(11, 122, 117, .18);
}

/* ---------- buttons ---------- */

body .stApp .stButton > button,
body .stApp [data-testid="stDownloadButton"] > button {
    min-height: 44px;
    border-radius: 10px;
    border: 1px solid var(--line);
    background: #fff;
    color: var(--ink);
    font-weight: 600;
    transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease;
}

body .stApp .stButton > button:hover,
body .stApp [data-testid="stDownloadButton"] > button:hover {
    border-color: var(--ink);
    color: var(--ink);
    transform: translateY(-1px);
}

body .stApp .stButton > button p,
body .stApp [data-testid="stDownloadButton"] > button p {
    margin: 0;
    font: inherit;
    color: inherit;
}

body .stApp .stButton > button[kind="primary"],
body .stApp .stButton > button[data-testid="stBaseButton-primary"] {
    min-height: 62px;
    border: 1.5px solid var(--ink);
    border-radius: 14px;
    background: var(--marigold);
    color: var(--ink);
    font: 700 20px/1 var(--font-display);
    letter-spacing: -.01em;
    box-shadow: 0 4px 0 var(--ink);
}

body .stApp .stButton > button[kind="primary"]:hover,
body .stApp .stButton > button[data-testid="stBaseButton-primary"]:hover {
    background: #FFB21F;
    border-color: var(--ink);
    transform: translateY(-1px);
    box-shadow: 0 5px 0 var(--ink);
}

body .stApp .stButton > button[kind="primary"]:active,
body .stApp .stButton > button[data-testid="stBaseButton-primary"]:active {
    transform: translateY(3px);
    box-shadow: 0 1px 0 var(--ink);
}

body .stApp .stButton > button:disabled {
    background: var(--line-soft);
    color: var(--muted);
    border-color: var(--line);
    box-shadow: none;
    transform: none;
}

body .stApp [class*="st-key-run_zone"] .stButton,
body .stApp [class*="st-key-run_zone"] .stButton > button,
body .stApp [class*="st-key-nbh_row_"] .stButton > button,
body .stApp [class*="st-key-wh_row_"] .stButton > button { width: 100%; }

body .stApp button:focus-visible,
body .stApp [role="radio"]:focus-visible,
body .stApp input:focus-visible {
    outline: 3px solid var(--teal);
    outline-offset: 2px;
}

/* ---------- radio as segmented choice ---------- */

body .stApp [data-testid="stRadio"] [role="radiogroup"] { gap: 10px; }

body .stApp [data-testid="stRadio"] label[data-baseweb="radio"] {
    margin: 0;
    padding: 11px 16px;
    border: 1px solid var(--line);
    border-radius: 12px;
    background: #fff;
    transition: border-color .12s ease, box-shadow .12s ease;
}

body .stApp [data-testid="stRadio"] label[data-baseweb="radio"]:hover {
    border-color: var(--ink);
}

body .stApp [data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) {
    border-color: var(--ink);
    box-shadow: inset 0 0 0 1px var(--ink);
    background: #FFF8E6;
}

/* ---------- sidebar ---------- */

[data-testid="stSidebar"] {
    background: var(--panel);
    border-right: 1px solid var(--line);
}

.gp-side-title {
    margin: 4px 0 4px;
    font: 700 24px/1.1 var(--font-display);
    letter-spacing: -.02em;
    color: var(--ink);
}

.gp-side-sub {
    margin: 0 0 18px;
    font-size: 14px;
    line-height: 1.5;
    color: var(--muted);
}

/* ---------- expander, alerts ---------- */

[data-testid="stExpander"] details {
    border: 1px solid var(--line);
    border-radius: 12px;
    background: var(--panel);
}

[data-testid="stExpander"] summary { font-weight: 600; }
[data-testid="stAlert"] { border-radius: 12px; }

/* ---------- map frame ---------- */

.st-key-map_frame iframe {
    display: block;
    border: 1px solid var(--line);
    border-radius: 18px;
    box-shadow: 0 18px 40px -26px rgba(15, 42, 67, .45);
}

/* ---------- solving loader ---------- */

.gp-solving {
    display: flex;
    align-items: center;
    gap: 22px;
    margin: 16px 0 4px;
    padding: 22px 26px;
    border: 1px solid var(--line);
    border-radius: 16px;
    background: var(--panel);
}

.gp-solving strong {
    display: block;
    font: 700 19px/1.2 var(--font-display);
    color: var(--ink);
}

.gp-solving p {
    margin: 4px 0 0;
    font-size: 14px;
    line-height: 1.5;
    color: var(--muted);
}

.gp-radar {
    position: relative;
    flex: none;
    width: 64px;
    height: 64px;
}

.gp-radar .core {
    position: absolute;
    inset: 22px;
    background: var(--marigold);
    border: 2.5px solid var(--ink);
    border-radius: 3px;
    animation: gp-turn 1.8s cubic-bezier(.6, 0, .2, 1) infinite;
}

.gp-radar .ring {
    position: absolute;
    inset: 0;
    border: 2px solid var(--teal);
    border-radius: 50%;
    opacity: 0;
    animation: gp-ring 1.8s ease-out infinite;
}

.gp-radar .ring:nth-child(2) { animation-delay: .6s; }
.gp-radar .ring:nth-child(3) { animation-delay: 1.2s; }

@keyframes gp-ring {
    from { transform: scale(.35); opacity: .9; }
    to   { transform: scale(1.15); opacity: 0; }
}

@keyframes gp-turn {
    0%, 40%  { transform: rotate(0deg); }
    70%, 100% { transform: rotate(90deg); }
}

/* ---------- pills ---------- */

.gp-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 5px 12px 5px 10px;
    border-radius: 999px;
    font: 600 13px/1 var(--font-body);
}

.gp-pill i {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
}

.gp-pill.ok { background: #DDF3EA; color: #0A5F3F; }
.gp-pill.warn { background: #FFEBC2; color: #7A4B00; }

/* ---------- plan summary ---------- */

.gp-plan {
    padding: 26px 28px 8px;
    border: 1px solid var(--line);
    border-radius: 18px;
    background: var(--panel);
}

.gp-plan h3 {
    margin: 12px 0 0;
    padding: 0;
    font: 700 26px/1.15 var(--font-display);
    letter-spacing: -.02em;
}

.gp-total {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    gap: 6px 16px;
    margin-top: 22px;
}

.gp-total .lab { font-size: 15px; color: var(--muted); }

.gp-total .num {
    font: 700 46px/1 var(--font-display);
    letter-spacing: -.03em;
    font-variant-numeric: tabular-nums;
    color: var(--ink);
}

.gp-split {
    display: flex;
    height: 12px;
    margin-top: 16px;
    overflow: hidden;
    border-radius: 4px;
    background: var(--line-soft);
}

.gp-split .seg { height: 100%; }
.gp-split .seg.d { background: var(--teal); }
.gp-split .seg.f { background: var(--marigold); }

.gp-split-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 26px;
    margin-top: 10px;
    font-size: 14px;
    color: var(--muted);
}

.gp-split-legend b {
    font-weight: 600;
    color: var(--ink);
    font-variant-numeric: tabular-nums;
}

.gp-split-legend i {
    display: inline-block;
    width: 10px;
    height: 10px;
    margin-right: 8px;
    border-radius: 2px;
}

.gp-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
    margin: 24px -28px 0;
    border-top: 1px solid var(--line-soft);
}

.gp-stats > div {
    padding: 18px 28px 20px;
    border-right: 1px solid var(--line-soft);
}

.gp-stats > div:last-child { border-right: none; }

.gp-stats dt { font-size: 13.5px; color: var(--muted); margin: 0; }

.gp-stats dd {
    margin: 4px 0 0;
    font: 700 24px/1.1 var(--font-display);
    letter-spacing: -.02em;
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
    color: var(--ink);
}

@media (max-width: 640px) {
    .gp-stats dd { font-size: 21px; }
    .gp-plan { padding: 20px 18px 4px; }
    .gp-total .num { font-size: 36px; }
    .gp-stats { margin: 20px -18px 0; }
    .gp-stats > div { padding: 14px 18px; border-right: none; border-bottom: 1px solid var(--line-soft); }
}

/* ---------- warehouse cards ---------- */

.gp-wh-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 14px;
}

.gp-wh {
    display: flex;
    gap: 14px;
    padding: 18px 20px;
    border: 1px solid var(--line);
    border-radius: 14px;
    background: var(--panel);
}

.gp-sq {
    flex: none;
    display: inline-block;
    width: 18px;
    height: 18px;
    margin-top: 2px;
    border: 2.5px solid var(--ink);
    border-radius: 3px;
    background: var(--c, var(--marigold));
    box-sizing: border-box;
}

.gp-wh h4 {
    margin: 0 0 8px;
    padding: 0;
    font: 700 18px/1.2 var(--font-display);
    letter-spacing: -.01em;
}

.gp-wh dl { margin: 0; }

.gp-wh dl > div {
    display: flex;
    justify-content: space-between;
    gap: 18px;
    padding: 3px 0;
    font-size: 14px;
}

.gp-wh dt { color: var(--muted); }
.gp-wh dd { margin: 0; font-weight: 600; font-variant-numeric: tabular-nums; text-align: right; }

/* ---------- utilisation bars ---------- */

.gp-util {
    padding: 8px 24px;
    border: 1px solid var(--line);
    border-radius: 16px;
    background: var(--panel);
}

.gp-util-row {
    display: grid;
    grid-template-columns: minmax(150px, 1.1fr) 3fr minmax(140px, 1fr);
    align-items: center;
    gap: 20px;
    padding: 16px 0;
    border-bottom: 1px solid var(--line-soft);
}

.gp-util-row:last-child { border-bottom: none; }

.gp-util-name {
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    font-size: 15px;
}

.gp-bar {
    height: 14px;
    overflow: hidden;
    border-radius: 4px;
    background: var(--line-soft);
}

.gp-bar b {
    display: block;
    height: 100%;
    width: var(--w);
    border-radius: 4px;
    background: var(--c);
    animation: gp-fill .9s cubic-bezier(.2, .7, .2, 1) both;
    animation-delay: calc(var(--i, 0) * 110ms + 120ms);
}

@keyframes gp-fill { from { width: 0; } to { width: var(--w); } }

.gp-util-val { text-align: right; line-height: 1.25; }
.gp-util-val strong { display: block; font: 700 19px var(--font-display); font-variant-numeric: tabular-nums; }
.gp-util-val span { font-size: 13px; color: var(--muted); font-variant-numeric: tabular-nums; }

@media (max-width: 720px) {
    .gp-util-row { grid-template-columns: 1fr; gap: 8px; }
    .gp-util-val { text-align: left; }
}

/* ---------- table ---------- */

.gp-table-wrap {
    max-height: 420px;
    overflow: auto;
    border: 1px solid var(--line);
    border-radius: 14px;
    background: var(--panel);
}

.gp-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14.5px;
}

.gp-table th {
    position: sticky;
    top: 0;
    padding: 12px 18px;
    background: #EEF3F6;
    border-bottom: 1px solid var(--line);
    text-align: left;
    font-weight: 600;
    color: var(--muted);
    white-space: nowrap;
}

.gp-table td {
    padding: 12px 18px;
    border-bottom: 1px solid var(--line-soft);
    white-space: nowrap;
}

.gp-table tr:last-child td { border-bottom: none; }
.gp-table .num { text-align: right; font-variant-numeric: tabular-nums; }
.gp-table td .gp-sq { width: 12px; height: 12px; margin: 0 10px 0 0; border-width: 2px; vertical-align: -1px; }

/* ---------- empty / problem panels ---------- */

.gp-empty {
    display: flex;
    gap: 18px;
    align-items: center;
    padding: 26px 28px;
    border: 1.5px dashed #9FB2C0;
    border-radius: 16px;
    color: var(--muted);
    font-size: 15px;
    line-height: 1.5;
}

.gp-empty svg { flex: none; }
.gp-empty strong { display: block; margin-bottom: 2px; font: 700 18px var(--font-display); color: var(--ink); }

.gp-problem {
    padding: 24px 28px;
    border: 1px solid #E4B75A;
    border-radius: 16px;
    background: #FFF6DF;
}

.gp-problem h3 { margin: 12px 0 6px; padding: 0; font: 700 22px/1.2 var(--font-display); }
.gp-problem p { margin: 0 0 6px; font-size: 15px; line-height: 1.55; color: #4A3A12; }
.gp-problem ul { margin: 8px 0 0 18px; padding: 0; color: #4A3A12; font-size: 15px; line-height: 1.6; }

/* ---------- footer ---------- */

.gp-foot {
    margin-top: 56px;
    padding-top: 18px;
    border-top: 1px solid var(--line);
    font-size: 13.5px;
    line-height: 1.55;
    color: var(--muted);
}

.gp-foot b { font-family: var(--font-display); color: var(--ink); }

/* ---------- motion preferences ---------- */

@media (prefers-reduced-motion: reduce) {
    .gp-bar b, .gp-radar .core, .gp-radar .ring { animation: none; }
    .gp-radar .ring { opacity: .35; transform: scale(.8); }
    body .stApp .stButton > button { transition: none; }
}
"""


def inject_theme():
    st.markdown(f"<style>{_compact(CSS)}</style>", unsafe_allow_html=True)


# ------------------------------------------------------------------
# SMALL COMPONENTS
# ------------------------------------------------------------------

def step(number, title, subtitle):
    html_block(
        f"""
        <div class="gp-step">
        <span class="gp-step-n" aria-hidden="true">{number}</span>
        <div>
        <h2 class="gp-step-title">{esc(title)}</h2>
        <p class="gp-step-sub">{esc(subtitle)}</p>
        </div>
        </div>
        """
    )


def subhead(title, note=""):
    small = f"<small>{esc(note)}</small>" if note else ""
    html_block(f'<h3 class="gp-sub">{esc(title)}{small}</h3>')


def field_label(kind, text):
    """kind is 'demand' (circle) or 'supply' (square)."""
    return (
        f'<div class="gp-label"><span class="gp-mark {kind}"></span>'
        f"{esc(text)}</div>"
    )


def sidebar_title(title, subtitle):
    html_block(
        f"""
        <div class="gp-side-title">{esc(title)}</div>
        <p class="gp-side-sub">{esc(subtitle)}</p>
        """
    )


def solving_html():
    return _compact(
        """
        <div class="gp-solving" role="status" aria-live="polite">
        <div class="gp-radar" aria-hidden="true">
        <span class="ring"></span><span class="ring"></span><span class="ring"></span>
        <span class="core"></span>
        </div>
        <div>
        <strong>Finding the best warehouse network</strong>
        <p>Comparing warehouse combinations against your delivery costs and capacity limits.</p>
        </div>
        </div>
        """
    )


def empty_state(title, text):
    html_block(
        f"""
        <div class="gp-empty">
        <svg width="54" height="54" viewBox="0 0 54 54" aria-hidden="true">
        <circle cx="16" cy="16" r="7" fill="{DEMAND}"/>
        <circle cx="40" cy="20" r="5" fill="{DEMAND}"/>
        <rect x="20" y="30" width="18" height="18" rx="3" fill="{MARIGOLD}" stroke="{INK}" stroke-width="2.5"/>
        </svg>
        <div><strong>{esc(title)}</strong>{esc(text)}</div>
        </div>
        """
    )


def problem_panel(status, message, suggestions):
    items = "".join(f"<li>{esc(s)}</li>" for s in suggestions)
    html_block(
        f"""
        <div class="gp-problem">
        <span class="gp-pill warn"><i></i>Solver status: {esc(status)}</span>
        <h3>No plan fits these limits</h3>
        <p>{esc(message)}</p>
        <ul>{items}</ul>
        </div>
        """
    )


def footer():
    html_block(
        """
        <div class="gp-foot">
        <b>GEONEXUS</b> plans warehouse networks from the inputs above.
        Distances are straight-line (haversine) estimates, not road distances,
        so check shortlisted sites against real driving times.
        </div>
        """
    )


# ------------------------------------------------------------------
# RESULTS COMPONENTS
# ------------------------------------------------------------------

def plan_summary(is_optimal, status, opened_count, candidate_count, metrics):
    total = float(metrics.get("total_cost", 0) or 0)
    delivery = float(metrics.get("delivery_cost", 0) or 0)
    fixed = float(metrics.get("fixed_cost", 0) or 0)

    base = delivery + fixed
    d_pct = (delivery / base * 100) if base > 0 else 50
    f_pct = 100 - d_pct

    pill_class = "ok" if is_optimal else "warn"
    pill_text = "Optimal plan" if is_optimal else f"Solver status: {status}"
    noun = "warehouse" if opened_count == 1 else "warehouses"

    note = (
        "Compared with serving each neighborhood from its nearest "
        "candidate warehouse."
    )
    stats = [
        ("Orders per day", f"{int(metrics.get('total_orders', 0) or 0):,}", "Total across all neighborhoods"),
        ("Average distance", f"{float(metrics.get('average_distance', 0) or 0):.2f} km", "Simple average per neighborhood"),
        ("Distance per order", f"{float(metrics.get('weighted_average_distance', 0) or 0):.2f} km", "Weighted by daily orders"),
        ("Delivery cost savings", money(metrics.get("cost_savings", 0)), note),
        ("Savings rate", f"{float(metrics.get('cost_savings_percent', 0) or 0):.2f}%", note),
    ]
    stats_html = "".join(
        f'<div title="{esc(n)}"><dt>{esc(l)}</dt><dd>{esc(v)}</dd></div>'
        for l, v, n in stats
    )

    html_block(
        f"""
        <section class="gp-plan">
        <span class="gp-pill {pill_class}"><i></i>{esc(pill_text)}</span>
        <h3>Open {opened_count} of {candidate_count} candidate {noun}</h3>
        <div class="gp-total">
        <span class="lab">Total daily cost</span>
        <span class="num">{esc(money(total))}</span>
        </div>
        <div class="gp-split" role="img"
        aria-label="Delivery {d_pct:.0f} percent, fixed {f_pct:.0f} percent">
        <div class="seg d" style="width:{d_pct:.2f}%"></div>
        <div class="seg f" style="width:{f_pct:.2f}%"></div>
        </div>
        <div class="gp-split-legend">
        <span><i style="background:{TEAL}"></i>Delivery <b>{esc(money(delivery))}</b></span>
        <span><i style="background:{MARIGOLD}"></i>Fixed <b>{esc(money(fixed))}</b></span>
        </div>
        <dl class="gp-stats">{stats_html}</dl>
        </section>
        """
    )


def warehouse_cards(rows):
    """rows: list of dicts with name, capacity, fixed_cost, lat, lon, color."""
    cards = []
    for row in rows:
        details = []
        if row.get("capacity") is not None:
            details.append(("Capacity", f"{int(row['capacity']):,} orders/day"))
        if row.get("fixed_cost") is not None:
            details.append(("Fixed cost", money(row["fixed_cost"])))
        if row.get("lat") is not None:
            details.append(("Location", f"{row['lat']:.4f}, {row['lon']:.4f}"))
        dl = "".join(
            f"<div><dt>{esc(k)}</dt><dd>{esc(v)}</dd></div>" for k, v in details
        )
        cards.append(
            f'<article class="gp-wh"><span class="gp-sq" style="--c:{row["color"]}"></span>'
            f"<div><h4>{esc(row['name'])}</h4><dl>{dl}</dl></div></article>"
        )
    html_block(f'<div class="gp-wh-grid">{"".join(cards)}</div>')


def utilization_bars(rows):
    """rows: list of dicts with name, assigned, capacity, color."""
    out = []
    for i, row in enumerate(rows):
        capacity = float(row["capacity"]) or 1.0
        assigned = float(row["assigned"])
        pct = max(0.0, assigned / capacity * 100)
        width = min(pct, 100)
        out.append(
            f"""
            <div class="gp-util-row">
            <div class="gp-util-name"><span class="gp-sq" style="--c:{row['color']}"></span>{esc(row['name'])}</div>
            <div class="gp-bar" role="img" aria-label="{pct:.0f} percent of capacity used">
            <b style="--w:{width:.1f}%;--c:{row['color']};--i:{i}"></b></div>
            <div class="gp-util-val"><strong>{pct:.0f}%</strong>
            <span>{assigned:,.0f} of {capacity:,.0f} orders</span></div>
            </div>
            """
        )
    html_block(f'<div class="gp-util">{"".join(out)}</div>')


def _format_cell(column, value):
    if pd.isna(value):
        return ""
    name = str(column).lower()
    if isinstance(value, (int, float, np.integer, np.floating)):
        if "cost" in name:
            return money(value)
        if "distance" in name:
            return f"{float(value):.2f}"
        if float(value).is_integer():
            return f"{int(value):,}"
        return f"{float(value):,.2f}"
    return str(value)


def data_table(df, colors=None, color_column="Warehouse"):
    """
    Render a DataFrame as themed HTML.
    colors maps a warehouse name to a hex colour for the swatch.
    """
    colors = colors or {}
    numeric = {c: pd.api.types.is_numeric_dtype(df[c]) for c in df.columns}

    head = "".join(
        f'<th class="{"num" if numeric[c] else ""}">{esc(c)}</th>'
        for c in df.columns
    )

    body = []
    for _, row in df.iterrows():
        cells = []
        for c in df.columns:
            text = esc(_format_cell(c, row[c]))
            if c == color_column and str(row[c]) in colors:
                swatch = f'<span class="gp-sq" style="--c:{colors[str(row[c])]}"></span>'
                text = swatch + text
            cells.append(f'<td class="{"num" if numeric[c] else ""}">{text}</td>')
        body.append(f'<tr>{"".join(cells)}</tr>')

    html_block(
        f'<div class="gp-table-wrap"><table class="gp-table">'
        f'<thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'
    )


# ------------------------------------------------------------------
# MAP ASSETS (rendered inside the folium iframe)
# ------------------------------------------------------------------

MAP_CSS = """
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;700&family=Instrument+Sans:wght@400;600&display=swap" rel="stylesheet">
<style>
.gp-div { background: none; border: none; }
.gp-wm { position: relative; width: 32px; height: 32px; }
.gp-wm .sq {
    position: absolute; inset: 6px;
    background: var(--c); border: 2.5px solid #0F2A43; border-radius: 3px;
    box-shadow: 0 3px 8px rgba(15, 42, 67, .4);
}
.gp-wm .pulse {
    position: absolute; inset: 0; border-radius: 50%;
    background: var(--c); opacity: .55;
    animation: gp-pulse 2.6s ease-out infinite;
}
.gp-wm.closed .sq {
    inset: 8px; background: #fff; border: 2px dashed #8A9BAA;
    box-shadow: none;
}
@keyframes gp-pulse {
    from { transform: scale(.55); opacity: .55; }
    to   { transform: scale(1.6); opacity: 0; }
}
.leaflet-popup-content-wrapper {
    border-radius: 12px; box-shadow: 0 10px 28px rgba(15, 42, 67, .25);
}
.leaflet-popup-content { margin: 14px 16px; font-family: 'Instrument Sans', system-ui, sans-serif; color: #0F2A43; }
.gp-pop strong { display: block; margin-bottom: 6px; font: 700 15px 'Bricolage Grotesque', system-ui, sans-serif; }
.gp-pop span { display: block; font-size: 13px; line-height: 1.55; color: #4F6275; }
.gp-pop b { color: #0F2A43; font-weight: 600; }
.leaflet-tooltip { font-family: 'Instrument Sans', system-ui, sans-serif; font-size: 13px; border-radius: 8px; border: 1px solid #C8D4DD; color: #0F2A43; }
.gp-legend {
    position: fixed; left: 16px; bottom: 28px; z-index: 9999;
    padding: 14px 16px; width: 236px;
    background: rgba(251, 253, 254, .94); backdrop-filter: blur(6px);
    border: 1px solid #C8D4DD; border-radius: 14px;
    box-shadow: 0 10px 28px rgba(15, 42, 67, .18);
    font: 400 13px/1.4 'Instrument Sans', system-ui, sans-serif; color: #0F2A43;
}
.gp-legend strong { display: block; margin-bottom: 10px; font: 700 14px 'Bricolage Grotesque', system-ui, sans-serif; }
.gp-legend div { display: flex; align-items: center; gap: 10px; margin-top: 8px; }
.gp-legend i { flex: none; display: inline-block; width: 14px; height: 14px; box-sizing: border-box; }
.gp-legend .c { border-radius: 50%; background: #3C5A75; border: 2px solid #fff; box-shadow: 0 0 0 1px #3C5A75; }
.gp-legend .s { border-radius: 2px; background: #F4A300; border: 2.5px solid #0F2A43; }
.gp-legend .h { border-radius: 2px; background: #fff; border: 2px dashed #8A9BAA; }
.gp-legend .l { height: 0; border-top: 3px dashed #0B7A75; width: 14px; }
.gp-legend p { margin: 10px 0 0; padding-top: 8px; border-top: 1px solid #DCE5EB; color: #4F6275; font-size: 12px; }
@media (prefers-reduced-motion: reduce) { .gp-wm .pulse { animation: none; opacity: .25; } }
</style>
"""


def map_legend():
    return _compact(
        """
        <div class="gp-legend">
        <strong>Reading the map</strong>
        <div><i class="c"></i>Neighborhood (larger = more orders)</div>
        <div><i class="s"></i>Warehouse to open</div>
        <div><i class="h"></i>Candidate left closed</div>
        <div><i class="l"></i>Delivery route</div>
        <p>Each colour is one warehouse and the neighborhoods it serves.</p>
        </div>
        """
    )


def warehouse_marker_html(color, is_open):
    if is_open:
        return (
            f'<div class="gp-wm" style="--c:{color}">'
            '<span class="pulse"></span><span class="sq"></span></div>'
        )
    return '<div class="gp-wm closed"><span class="sq"></span></div>'


# ------------------------------------------------------------------
# HERO
# ------------------------------------------------------------------

HERO_HTML = r"""
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Instrument+Sans:wght@400..600&display=swap" rel="stylesheet">
<style>
:root {
  --paper: #F4F8FA; --ink: #0F2A43; --muted: #4F6275; --line: #C8D4DD;
  --gold: #F4A300; --teal: #0B7A75;
  --display: 'Bricolage Grotesque', 'Segoe UI', system-ui, sans-serif;
  --body: 'Instrument Sans', 'Segoe UI', system-ui, sans-serif;
}
* { box-sizing: border-box; margin: 0; }
html, body { height: 100%; }
body {
  font-family: var(--body); color: var(--ink); overflow: hidden;
  background-color: var(--paper);
  background-image:
    linear-gradient(rgba(15,42,67,.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(15,42,67,.05) 1px, transparent 1px);
  background-size: 48px 48px;
}
.hero {
  height: 100%; display: grid; align-items: center;
  grid-template-columns: minmax(0, 5fr) minmax(0, 6fr);
  padding: 0 0 0 48px;
}
.brand { display: flex; align-items: center; gap: 11px; font: 800 17px var(--display); letter-spacing: .08em; }
h1 {
  margin: 24px 0 18px; max-width: 11em;
  font: 700 clamp(32px, 4.4vw, 52px)/1.02 var(--display); letter-spacing: -.028em;
}
.lede { max-width: 33em; font-size: 16.5px; line-height: 1.55; color: var(--muted); }

.stage { position: relative; height: 100%; min-width: 0; }
.stage svg { position: absolute; inset: 0; width: 100%; height: 100%; }

.readout {
  display: inline-flex; align-items: center; gap: 18px; margin-top: 24px; padding: 13px 22px 13px 20px;
  background: rgba(251,253,254,.94); border: 1px solid var(--line); border-radius: 14px;
  box-shadow: 0 12px 28px -18px rgba(15,42,67,.45);
}
.readout .num { min-width: 3.6ch; font: 700 42px/1 var(--display); letter-spacing: -.03em; font-variant-numeric: tabular-nums; }
.readout .num { white-space: nowrap; }
.readout .num small { margin-left: 5px; font: 500 15px var(--body); letter-spacing: 0; color: var(--muted); }
.readout .meta { display: flex; flex-direction: column; gap: 3px; min-width: 250px; padding-left: 18px; border-left: 1px solid var(--line); }
.readout .lab { font-size: 13px; color: var(--muted); }
.readout .note { min-height: 18px; font-size: 14px; font-weight: 600; color: var(--teal); }

.key { position: absolute; left: 4px; bottom: 20px; display: flex; gap: 20px; font-size: 13px; color: var(--muted); }
.key span { display: flex; align-items: center; gap: 8px; }
.key i { display: inline-block; width: 12px; height: 12px; box-sizing: border-box; }
.key .c { border-radius: 50%; background: #3C5A75; }
.key .s { border-radius: 2px; background: var(--gold); border: 2px solid var(--ink); }

.replay {
  position: absolute; right: 24px; bottom: 16px; padding: 7px 14px;
  font: 600 13px var(--body); color: var(--ink); background: #fff;
  border: 1px solid var(--line); border-radius: 999px; cursor: pointer;
  transition: border-color .12s ease, transform .12s ease;
}
.replay:hover { border-color: var(--ink); transform: translateY(-1px); }
.replay:focus-visible { outline: 3px solid var(--teal); outline-offset: 2px; }

.streets { animation: fadein 1s ease both; }
@keyframes fadein { from { opacity: 0; } to { opacity: 1; } }

.ring { fill: none; stroke-width: 2; transform-box: fill-box; transform-origin: center; opacity: 0; }
.ring.on { animation: ping 2.8s ease-out infinite; }
@keyframes ping { from { transform: scale(.7); opacity: .6; } to { transform: scale(2.3); opacity: 0; } }

@media (max-width: 760px) {
  .hero { grid-template-columns: 1fr; grid-template-rows: auto 1fr; padding: 22px 20px 0; align-items: start; }
  h1 { margin: 14px 0 0; font-size: 28px; }
  .lede { display: none; }
  .readout { display: flex; margin-top: 14px; gap: 12px; padding: 9px 14px; }
  .readout .num { font-size: 28px; }
  .readout .meta { min-width: 0; padding-left: 12px; }
  .readout .lab { display: none; }
  .readout .note { font-size: 12.5px; }
  .key { left: 0; bottom: 8px; gap: 14px; font-size: 12px; }
  .replay { right: 8px; bottom: 4px; }
}

@media (prefers-reduced-motion: reduce) {
  .streets, .ring.on { animation: none; }
  .ring { display: none; }
  .replay { display: none; }
}
</style>
</head>
<body>
<main class="hero">
  <section>
    <div class="brand">
      <svg width="30" height="30" viewBox="0 0 30 30" aria-hidden="true">
        <rect x="2" y="12" width="15" height="15" rx="2.5" fill="#F4A300" stroke="#0F2A43" stroke-width="2.5"/>
        <circle cx="20" cy="10" r="7" fill="#0B7A75" stroke="#F4F8FA" stroke-width="2.5"/>
      </svg>
      GEONEXUS
    </div>
    <h1>Where should your next warehouse go?</h1>
    <p class="lede">Add the neighborhoods you deliver to and how many orders each one places. GEONEXUS picks the warehouse locations with the lowest combined delivery and fixed cost.</p>
    <div class="readout" aria-live="polite">
      <div class="num"><span id="km">0</span><small>km</small></div>
      <div class="meta">
        <span class="lab">Daily delivery distance (illustration)</span>
        <span class="note" id="note">Neighborhoods placing orders</span>
      </div>
    </div>
  </section>

  <section class="stage">
    <svg id="map" viewBox="0 0 600 440" preserveAspectRatio="xMidYMid meet" role="img"
         aria-label="Illustration: sixteen neighborhoods are served by one warehouse. A second warehouse opens and the eastern neighborhoods switch to it, shortening total delivery distance.">
      <g class="streets" fill="none" stroke-linecap="round">
        <path d="M226 388 q34 -26 76 -10 q22 20 -4 34 q-52 14 -72 -24z" fill="#DCEBF1" stroke="none"/>
        <path d="M508 44 q30 -14 56 4 q6 22 -20 26 q-34 2 -36 -30z" fill="#DCEBF1" stroke="none"/>
        <path d="M20 300 C150 262 220 214 300 225 S470 252 585 190" stroke="#D3DEE6" stroke-width="5"/>
        <path d="M120 8 C180 120 262 192 300 225 S400 330 470 432" stroke="#D3DEE6" stroke-width="5"/>
        <path d="M300 8 L300 432" stroke="#DCE5EB" stroke-width="3"/>
        <ellipse cx="300" cy="225" rx="262" ry="184" stroke="#CBD8E1" stroke-width="9"/>
        <ellipse cx="300" cy="225" rx="262" ry="184" stroke="#F4F8FA" stroke-width="1.5" stroke-dasharray="7 8"/>
      </g>
      <g id="lines"></g>
      <g id="custs"></g>
      <g id="whs"></g>
    </svg>

    <div class="key">
      <span><i class="c"></i>Neighborhood</span>
      <span><i class="s"></i>Warehouse</span>
    </div>
    <button class="replay" id="replay" type="button" aria-label="Replay the animation">Replay</button>
  </section>
</main>

<script>
(function () {
  var NS = 'http://www.w3.org/2000/svg';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var W = [
    { x: 170, y: 228, color: '#F4A300', name: 'Warehouse 1' },
    { x: 440, y: 214, color: '#0B7A75', name: 'Warehouse 2' }
  ];
  var west = [[92,150,5],[140,96,4],[214,112,6],[66,236,5],[118,308,7],[212,300,4],[262,186,5],[168,360,4]];
  var east = [[350,118,5],[424,86,7],[512,140,4],[486,232,6],[548,300,5],[408,318,7],[346,262,4],[468,372,5]];
  var pts = [];
  for (var i = 0; i < 8; i++) { pts.push(west[i]); pts.push(east[i]); }

  var NEUTRAL = '#3C5A75', SCALE = 0.06;
  var linesG = document.getElementById('lines');
  var custG = document.getElementById('custs');
  var whG = document.getElementById('whs');
  var kmEl = document.getElementById('km');
  var noteEl = document.getElementById('note');

  function el(name, attrs, parent) {
    var n = document.createElementNS(NS, name);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    parent.appendChild(n);
    return n;
  }
  function dist(ax, ay, bx, by) { return Math.hypot(ax - bx, ay - by); }
  function clamp(x) { return Math.max(0, Math.min(1, x)); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function easeOut(t) { return 1 - Math.pow(1 - t, 3); }
  function easeInOut(t) { return t < .5 ? 4*t*t*t : 1 - Math.pow(-2*t + 2, 3) / 2; }
  function back(t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
  function hex(c) { return [parseInt(c.substr(1,2),16), parseInt(c.substr(3,2),16), parseInt(c.substr(5,2),16)]; }
  function mixv(a, b, t) { return [lerp(a[0],b[0],t), lerp(a[1],b[1],t), lerp(a[2],b[2],t)]; }
  function css(v) { return 'rgb(' + Math.round(v[0]) + ',' + Math.round(v[1]) + ',' + Math.round(v[2]) + ')'; }

  var eastCount = 0, before = 0, after = 0;
  var C = pts.map(function (p, i) {
    var d1 = dist(p[0], p[1], W[0].x, W[0].y);
    var d2 = dist(p[0], p[1], W[1].x, W[1].y);
    var isEast = d2 < d1;
    before += d1; after += Math.min(d1, d2);
    var c = { x: p[0], y: p[1], r: p[2] * 1.15, east: isEast, k: isEast ? eastCount++ : 0, i: i };
    c.line = el('line', { x1: c.x, y1: c.y, x2: c.x, y2: c.y, 'stroke-width': 2.2, 'stroke-linecap': 'round', opacity: 0 }, linesG);
    c.dot = el('circle', { cx: c.x, cy: c.y, r: 0, fill: NEUTRAL, stroke: '#fff', 'stroke-width': 2 }, custG);
    return c;
  });
  before *= SCALE; after *= SCALE;
  var saved = Math.round((1 - after / before) * 100);

  var WH = W.map(function (w) {
    var g = el('g', { transform: 'translate(' + w.x + ',' + w.y + ') scale(0)' }, whG);
    w.ring = el('circle', { class: 'ring', cx: 0, cy: 0, r: 15, stroke: w.color }, g);
    el('rect', { x: -13, y: -13, width: 26, height: 26, rx: 3.5, fill: w.color, stroke: '#0F2A43', 'stroke-width': 3 }, g);
    var label = el('text', { x: 0, y: 32, 'text-anchor': 'middle', 'font-size': 12.5, 'font-weight': 600, fill: '#0F2A43', 'font-family': 'Instrument Sans, system-ui, sans-serif', stroke: '#F4F8FA', 'stroke-width': 4, 'paint-order': 'stroke', 'stroke-linejoin': 'round' }, g);
    label.textContent = w.name;
    return g;
  });

  function render(t) {
    var total = 0;
    C.forEach(function (c) {
      var p = easeOut(clamp((t - 300 - c.i * 42) / 320));
      c.dot.setAttribute('r', (c.r * p).toFixed(2));

      var d = easeOut(clamp((t - 1750 - c.i * 55) / 520));
      var s = c.east ? easeInOut(clamp((t - 3900 - c.k * 75) / 800)) : 0;
      var ex = lerp(W[0].x, W[1].x, s), ey = lerp(W[0].y, W[1].y, s);
      var x2 = c.x + (ex - c.x) * d, y2 = c.y + (ey - c.y) * d;
      var colv = mixv(hex(W[0].color), hex(W[1].color), s);

      c.line.setAttribute('x2', x2.toFixed(1));
      c.line.setAttribute('y2', y2.toFixed(1));
      c.line.setAttribute('stroke', css(colv));
      c.line.setAttribute('opacity', d > 0 ? 0.8 : 0);
      c.dot.setAttribute('fill', css(mixv(hex(NEUTRAL), colv, clamp(d * 3))));
      total += dist(c.x, c.y, x2, y2) * SCALE;
    });

    var p1 = back(clamp((t - 1300) / 550));
    var p2 = back(clamp((t - 3350) / 550));
    WH[0].setAttribute('transform', 'translate(' + W[0].x + ',' + W[0].y + ') scale(' + p1.toFixed(3) + ')');
    WH[1].setAttribute('transform', 'translate(' + W[1].x + ',' + W[1].y + ') scale(' + p2.toFixed(3) + ')');
    if (p1 > .95) W[0].ring.setAttribute('class', 'ring on');
    if (p2 > .95) W[1].ring.setAttribute('class', 'ring on');

    kmEl.textContent = Math.round(total);
    noteEl.textContent =
      t < 1300 ? 'Neighborhoods placing orders' :
      t < 3350 ? 'One warehouse serves everyone' :
      t < 4700 ? 'Switching to the nearest warehouse' :
      saved + '% shorter with a second warehouse';
  }

  var raf = null, START = 0, END = 5600;
  function frame(now) {
    var t = now - START;
    render(Math.min(t, END + 1));
    if (t < END) raf = requestAnimationFrame(frame); else raf = null;
  }
  function play() {
    if (raf) cancelAnimationFrame(raf);
    W.forEach(function (w) { w.ring.setAttribute('class', 'ring'); });
    START = performance.now();
    raf = requestAnimationFrame(frame);
  }

  document.getElementById('replay').addEventListener('click', play);
  if (reduce) { render(END + 1); } else { play(); }
})();
</script>
</body>
</html>
"""


def render_hero(height=480):
    markup = HERO_HTML
    with keyed_container("hero"):
        try:
            components.html(markup, height=height, scrolling=False)
        except Exception:
            st.title("GEONEXUS")
            st.caption("Where should your next warehouse go?")