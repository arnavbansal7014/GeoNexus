import numpy as np
import pandas as pd
import folium
import streamlit as st

from folium.plugins import AntPath
from streamlit_folium import st_folium
from streamlit_searchbox import st_searchbox

import theme
from optimizer import optimize_warehouses


# ============================================================
# PAGE CONFIG AND THEME
# ============================================================

st.set_page_config(
    page_title="GRIDPOINT | Warehouse location planning",
    page_icon="📍",
    layout="wide",
    initial_sidebar_state="expanded",
)

theme.inject_theme()


MODE_AUTO = "Suggest candidate locations for me"
MODE_MANUAL = "I'll choose the candidate locations"


# ============================================================
# BENGALURU LOCATION DATABASE
# ============================================================

BENGALURU_PLACES = [

    # ----------------------------
    # SOUTH / CENTRAL
    # ----------------------------

    ("Basavanagudi", 12.9432, 77.5736),
    ("Gandhi Bazaar", 12.9450, 77.5700),
    ("Jayanagar", 12.9250, 77.5938),
    ("Jayanagar 1st Block", 12.9270, 77.5890),
    ("Jayanagar 2nd Block", 12.9310, 77.5895),
    ("Jayanagar 3rd Block", 12.9295, 77.5920),
    ("Jayanagar 4th Block", 12.9255, 77.5945),
    ("Jayanagar 5th Block", 12.9205, 77.5920),
    ("Jayanagar 6th Block", 12.9160, 77.5900),
    ("Jayanagar 7th Block", 12.9130, 77.5950),
    ("Jayanagar 8th Block", 12.9170, 77.5990),
    ("Jayanagar 9th Block", 12.9200, 77.6020),

    ("JP Nagar", 12.9063, 77.5857),
    ("JP Nagar Phase 1", 12.9070, 77.5860),
    ("JP Nagar Phase 2", 12.9005, 77.5920),
    ("JP Nagar Phase 3", 12.8945, 77.5980),
    ("JP Nagar Phase 4", 12.9080, 77.5960),
    ("JP Nagar Phase 5", 12.9000, 77.6070),
    ("JP Nagar Phase 6", 12.9110, 77.6060),
    ("JP Nagar Phase 7", 12.8960, 77.6120),
    ("JP Nagar Phase 8", 12.8870, 77.6000),

    ("Banashankari", 12.9255, 77.5468),
    ("Banashankari 1st Stage", 12.9300, 77.5500),
    ("Banashankari 2nd Stage", 12.9200, 77.5550),
    ("Banashankari 3rd Stage", 12.9160, 77.5480),
    ("Padmanabhanagar", 12.9190, 77.5570),
    ("Kumaraswamy Layout", 12.9050, 77.5600),

    ("BTM Layout", 12.9166, 77.6101),
    ("BTM Layout 1st Stage", 12.9160, 77.6070),
    ("BTM Layout 2nd Stage", 12.9110, 77.6150),
    ("BTM Layout 3rd Stage", 12.9060, 77.6150),

    ("Koramangala", 12.9352, 77.6245),
    ("Koramangala 1st Block", 12.9360, 77.6200),
    ("Koramangala 2nd Block", 12.9340, 77.6240),
    ("Koramangala 3rd Block", 12.9310, 77.6260),
    ("Koramangala 4th Block", 12.9340, 77.6280),
    ("Koramangala 5th Block", 12.9345, 77.6190),
    ("Koramangala 6th Block", 12.9380, 77.6140),
    ("Koramangala 7th Block", 12.9420, 77.6180),
    ("Koramangala 8th Block", 12.9400, 77.6250),

    ("HSR Layout", 12.9116, 77.6474),
    ("HSR Layout Sector 1", 12.9130, 77.6440),
    ("HSR Layout Sector 2", 12.9160, 77.6500),
    ("HSR Layout Sector 3", 12.9180, 77.6550),
    ("HSR Layout Sector 4", 12.9080, 77.6540),
    ("HSR Layout Sector 5", 12.9060, 77.6460),
    ("HSR Layout Sector 6", 12.9000, 77.6480),
    ("HSR Layout Sector 7", 12.8970, 77.6420),

    ("Electronic City", 12.8452, 77.6602),
    ("Electronic City Phase 1", 12.8399, 77.6770),
    ("Electronic City Phase 2", 12.8340, 77.6740),

    ("Bommanahalli", 12.9081, 77.6240),
    ("Begur", 12.8780, 77.6240),
    ("Arekere", 12.8850, 77.5960),
    ("Bannerghatta Road", 12.8840, 77.5940),

    # ----------------------------
    # EAST
    # ----------------------------

    ("Indiranagar", 12.9784, 77.6408),
    ("Indiranagar 1st Stage", 12.9780, 77.6380),
    ("Indiranagar 2nd Stage", 12.9780, 77.6450),
    ("Domlur", 12.9600, 77.6387),
    ("HAL", 12.9560, 77.6560),
    ("Ulsoor", 12.9810, 77.6197),
    ("CV Raman Nagar", 12.9850, 77.6630),
    ("Kaggadasapura", 12.9850, 77.6700),

    ("Marathahalli", 12.9591, 77.6974),
    ("Brookefield", 12.9650, 77.7150),
    ("Whitefield", 12.9698, 77.7500),
    ("ITPL", 12.9850, 77.7350),
    ("Kadugodi", 12.9930, 77.7600),
    ("Varthur", 12.9400, 77.7460),
    ("Bellandur", 12.9304, 77.6784),
    ("Sarjapur Road", 12.9100, 77.6800),

    # ----------------------------
    # NORTH
    # ----------------------------

    ("Hebbal", 13.0358, 77.5970),
    ("RT Nagar", 13.0200, 77.5940),
    ("Sanjay Nagar", 13.0400, 77.5800),
    ("Yelahanka", 13.1007, 77.5963),
    ("Yelahanka New Town", 13.0990, 77.5840),
    ("Jakkur", 13.0780, 77.6050),
    ("Thanisandra", 13.0580, 77.6260),
    ("Hennur", 13.0260, 77.6300),
    ("Kalyan Nagar", 13.0220, 77.6400),
    ("Kammanahalli", 13.0150, 77.6380),
    ("Nagawara", 13.0430, 77.6170),

    # ----------------------------
    # WEST
    # ----------------------------

    ("Rajajinagar", 12.9910, 77.5540),
    ("Malleshwaram", 13.0035, 77.5700),
    ("Vijayanagar", 12.9710, 77.5380),
    ("Nagarbhavi", 12.9590, 77.5110),
    ("Kengeri", 12.9170, 77.4870),
    ("Nayandahalli", 12.9410, 77.5270),
    ("Peenya", 13.0280, 77.5190),
    ("Basaveshwaranagar", 12.9880, 77.5390),
    ("Kamakshipalya", 12.9760, 77.5310),
]

# ============================================================
# SESSION STATE
# ============================================================

DEFAULT_STATE = {
    "neighborhood_blocks": [{"id": 1, "location": None, "orders": 100}],
    "warehouse_blocks": [
        {"id": 1, "location": None, "capacity": 500, "fixed_cost": 5000}
    ],
    "optimization_result": None,
    "optimization_inputs": None,
    "neighborhood_counter": 2,
    "warehouse_counter": 2,
}

for state_key, default in DEFAULT_STATE.items():
    if state_key not in st.session_state:
        st.session_state[state_key] = default


# ============================================================
# SEARCH
# ============================================================

def search_bengaluru_places(searchterm):

    if not searchterm:
        return []

    q = searchterm.strip().lower()

    if not q:
        return []

    exact, starts, contains = [], [], []

    for name, _lat, _lon in BENGALURU_PLACES:

        name_lower = name.lower()

        if name_lower == q:
            exact.append(name)
        elif name_lower.startswith(q):
            starts.append(name)
        elif q in name_lower:
            contains.append(name)

    return (exact + starts + contains)[:10]


def location_selector(label, key, kind):
    """kind: 'demand' for neighborhoods, 'supply' for warehouses."""

    st.markdown(
        theme.field_label(kind, label),
        unsafe_allow_html=True,
    )

    selected = st_searchbox(
        search_bengaluru_places,
        placeholder="Search a Bengaluru neighborhood",
        key=key,
    )

    selected_state_key = f"{key}_selected"

    if selected:
        st.session_state[selected_state_key] = selected

    selected_name = st.session_state.get(selected_state_key)

    if selected_name:
        for name, lat, lon in BENGALURU_PLACES:
            if name == selected_name:
                return {"name": name, "lat": float(lat), "lon": float(lon)}

    return None


# ============================================================
# DATAFRAME HELPERS
# ============================================================

def safe_column_values(df, column_name):

    if not isinstance(df, pd.DataFrame) or column_name not in df.columns:
        return []

    values = df[column_name]

    if isinstance(values, pd.DataFrame):
        values = values.iloc[:, 0]

    return [str(value) for value in values.to_numpy()]


def remove_duplicate_columns(df):

    if not isinstance(df, pd.DataFrame):
        return pd.DataFrame()

    return df.loc[:, ~df.columns.duplicated(keep="first")]


def pick(df, *names):
    """Return the first column whose lower-cased name matches."""

    lookup = {str(c).lower().strip(): c for c in df.columns}

    for name in names:
        if name in lookup:
            return lookup[name]

    return None


def to_frame(data, key_name="customer_id", value_name="warehouse_id"):
    """Normalize a DataFrame, list or dict returned by the optimizer."""

    if isinstance(data, pd.DataFrame):
        return data.copy()

    if isinstance(data, list):
        return pd.DataFrame(data)

    if isinstance(data, dict):

        rows = []

        for key, value in data.items():

            if isinstance(value, dict):
                row = dict(value)
                row[key_name] = key
            else:
                row = {key_name: key, value_name: value}

            rows.append(row)

        return pd.DataFrame(rows)

    return pd.DataFrame()


def normalize_ids(opened):

    if isinstance(opened, pd.DataFrame):
        return (
            safe_column_values(opened, "id")
            or safe_column_values(opened, "warehouse_id")
        )

    if isinstance(opened, dict):
        return [str(k) for k, v in opened.items() if v]

    if isinstance(opened, (list, tuple, set)):
        return [str(x) for x in opened]

    return []


# ============================================================
# ADD / REMOVE ROWS
# ============================================================

def add_neighborhood():

    st.session_state.neighborhood_blocks.append(
        {
            "id": st.session_state.neighborhood_counter,
            "location": None,
            "orders": 100,
        }
    )

    st.session_state.neighborhood_counter += 1


def remove_neighborhood(block_id):

    st.session_state.neighborhood_blocks = [
        block
        for block in st.session_state.neighborhood_blocks
        if block["id"] != block_id
    ]


def add_warehouse():

    st.session_state.warehouse_blocks.append(
        {
            "id": st.session_state.warehouse_counter,
            "location": None,
            "capacity": 500,
            "fixed_cost": 5000,
        }
    )

    st.session_state.warehouse_counter += 1


def remove_warehouse(block_id):

    st.session_state.warehouse_blocks = [
        block
        for block in st.session_state.warehouse_blocks
        if block["id"] != block_id
    ]


# ============================================================
# AUTOMATIC CANDIDATE GENERATION
# ============================================================

def generate_warehouse_candidates(customers_df, requested_count):

    if customers_df.empty:
        return pd.DataFrame()

    total_orders = customers_df["orders"].sum()

    capacity = max(
        100,
        int(total_orders / max(requested_count, 1) * 1.35),
    )

    candidates = []

    def add_candidate(name, lat, lon):
        candidates.append(
            {
                "id": f"W{len(candidates) + 1}",
                "name": name,
                "latitude": float(lat),
                "longitude": float(lon),
                "capacity": capacity,
                "fixed_cost": 5000.0,
            }
        )

    # Every customer location is a candidate
    for _, row in customers_df.iterrows():
        add_candidate(
            f"Candidate near {row['name']}",
            row["latitude"],
            row["longitude"],
        )

    # Demand-weighted center
    add_candidate(
        "Central Bengaluru Candidate",
        np.average(customers_df["latitude"], weights=customers_df["orders"]),
        np.average(customers_df["longitude"], weights=customers_df["orders"]),
    )

    # Geographic center
    add_candidate(
        "Geographic Center Candidate",
        customers_df["latitude"].median(),
        customers_df["longitude"].median(),
    )

    return pd.DataFrame(candidates)


# ============================================================
# COLLECT INPUTS
# ============================================================

def collect_customers():

    rows, skipped = [], 0

    for index, block in enumerate(st.session_state.neighborhood_blocks):

        location = block.get("location")

        if location is None:
            skipped += 1
            continue

        rows.append(
            {
                "id": f"C{index + 1}",
                "name": location["name"],
                "latitude": float(location["lat"]),
                "longitude": float(location["lon"]),
                "orders": int(block["orders"]),
            }
        )

    return pd.DataFrame(rows), skipped


def collect_manual_warehouses():

    rows, skipped = [], 0

    for index, block in enumerate(st.session_state.warehouse_blocks):

        location = block.get("location")

        if location is None:
            skipped += 1
            continue

        rows.append(
            {
                "id": f"W{index + 1}",
                "name": location["name"],
                "latitude": float(location["lat"]),
                "longitude": float(location["lon"]),
                "capacity": int(block["capacity"]),
                "fixed_cost": float(block["fixed_cost"]),
            }
        )

    return pd.DataFrame(rows), skipped


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    theme.sidebar_title(
        "Plan settings",
        "The limits the optimizer has to respect.",
    )

    num_warehouses = st.number_input(
        "Maximum warehouses",
        min_value=1,
        max_value=20,
        value=3,
        step=1,
        help="The optimizer opens at most this many warehouses.",
    )

    cost_per_km = st.number_input(
        "Delivery cost per order per km (₹)",
        min_value=0.0,
        value=10.0,
        step=1.0,
    )

    enable_radius = st.checkbox(
        "Limit delivery radius",
        help="Neighborhoods can only be served from a warehouse within this distance.",
    )

    if enable_radius:
        max_radius = st.number_input(
            "Maximum radius (km)",
            min_value=0.1,
            value=10.0,
            step=0.5,
        )
    else:
        max_radius = None


# ============================================================
# HERO
# ============================================================

theme.render_hero()

with st.expander("What GRIDPOINT takes into account"):
    st.markdown(
        """
- Where each customer neighborhood is
- How many orders each neighborhood places per day
- Each warehouse's capacity and fixed cost
- The distance between neighborhoods and warehouses
- The maximum number of warehouses you can run
- An optional maximum delivery radius
"""
    )


# ============================================================
# 1  NEIGHBORHOODS
# ============================================================

theme.step(
    1,
    "Where your customers are",
    f"Search {len(BENGALURU_PLACES)} Bengaluru neighborhoods and set how many "
    "orders each one places per day.",
)

for index, block in enumerate(st.session_state.neighborhood_blocks):

    block_id = block["id"]

    with theme.keyed_container(f"nbh_row_{block_id}", border=True):

        col1, col2, col3 = st.columns([4, 2, 1])

        with col1:

            location = location_selector(
                f"Neighborhood {index + 1}",
                f"neighborhood_search_{block_id}",
                "demand",
            )

            if location:
                block["location"] = location

        with col2:

            block["orders"] = st.number_input(
                "Daily orders",
                min_value=1,
                value=int(block.get("orders", 100)),
                step=10,
                key=f"orders_{block_id}",
            )

        with col3:

            st.write("")

            if len(st.session_state.neighborhood_blocks) > 1:

                if st.button("Remove", key=f"remove_neighborhood_{block_id}"):
                    remove_neighborhood(block_id)
                    st.rerun()

st.button("Add neighborhood", on_click=add_neighborhood)


# ============================================================
# 2  WAREHOUSES
# ============================================================

theme.step(
    2,
    "Where warehouses could go",
    "GRIDPOINT opens the best of these candidates, up to the maximum "
    "number of warehouses in the sidebar.",
)

warehouse_mode = st.radio(
    "How should candidate locations be chosen?",
    [MODE_AUTO, MODE_MANUAL],
    horizontal=True,
)

if warehouse_mode == MODE_AUTO:

    st.caption(
        "Each neighborhood you add, plus the order-weighted center and the "
        "geographic center, becomes a candidate. Every candidate gets a fixed "
        "cost of ₹5,000 and capacity of about 135% of an even share of your "
        "daily orders."
    )

else:

    st.caption(
        "Add the sites you are considering, with the capacity and fixed cost "
        "of each."
    )

    for index, block in enumerate(st.session_state.warehouse_blocks):

        block_id = block["id"]

        with theme.keyed_container(f"wh_row_{block_id}", border=True):

            col1, col2, col3, col4 = st.columns([4, 2, 2, 1])

            with col1:

                location = location_selector(
                    f"Warehouse candidate {index + 1}",
                    f"warehouse_search_{block_id}",
                    "supply",
                )

                if location:
                    block["location"] = location

            with col2:

                block["capacity"] = st.number_input(
                    "Capacity (orders per day)",
                    min_value=1,
                    value=int(block.get("capacity", 500)),
                    step=50,
                    key=f"capacity_{block_id}",
                )

            with col3:

                block["fixed_cost"] = st.number_input(
                    "Fixed cost (₹)",
                    min_value=0.0,
                    value=float(block.get("fixed_cost", 5000)),
                    step=500.0,
                    key=f"fixed_cost_{block_id}",
                )

            with col4:

                st.write("")

                if len(st.session_state.warehouse_blocks) > 1:

                    if st.button("Remove", key=f"remove_warehouse_{block_id}"):
                        remove_warehouse(block_id)
                        st.rerun()

    st.button("Add warehouse candidate", on_click=add_warehouse)


# ============================================================
# 3  RUN
# ============================================================

theme.step(
    3,
    "Run the optimizer",
    "GRIDPOINT compares warehouse combinations and assigns every "
    "neighborhood to the warehouse that serves it best.",
)

ready_customers = sum(
    1 for b in st.session_state.neighborhood_blocks if b.get("location")
)

ready_warehouses = sum(
    1 for b in st.session_state.warehouse_blocks if b.get("location")
)

manual = warehouse_mode == MODE_MANUAL

can_run = ready_customers > 0 and (not manual or ready_warehouses > 0)

with theme.keyed_container("run_zone"):

    run_optimization = st.button(
        "Optimize warehouse network",
        type="primary",
        disabled=not can_run,
    )

if not can_run:

    if ready_customers == 0:
        st.caption(
            "Pick at least one neighborhood from the search list to continue."
        )
    else:
        st.caption(
            "Pick at least one candidate warehouse location from the search "
            "list to continue."
        )

else:

    plural = "neighborhood" if ready_customers == 1 else "neighborhoods"
    message = f"{ready_customers} {plural} ready"

    if manual:
        w_plural = "candidate" if ready_warehouses == 1 else "candidates"
        message += f" and {ready_warehouses} warehouse {w_plural}"

    st.caption(message + ".")

status_slot = st.empty()


def run_optimization_flow():

    # A new run replaces any earlier result
    st.session_state.optimization_result = None
    st.session_state.optimization_inputs = None

    customers_df, skipped_customers = collect_customers()

    if customers_df.empty:
        st.error(
            "Add at least one neighborhood and pick its location from the "
            "search list."
        )
        return

    skipped_warehouses = 0

    if manual:

        warehouses_df, skipped_warehouses = collect_manual_warehouses()

        if warehouses_df.empty:
            st.error(
                "Add at least one warehouse candidate and pick its location "
                "from the search list."
            )
            return

    else:

        warehouses_df = generate_warehouse_candidates(
            customers_df, int(num_warehouses)
        )

        if warehouses_df.empty:
            st.error("GRIDPOINT could not generate warehouse candidates.")
            return

    skipped = skipped_customers + skipped_warehouses

    if skipped:
        st.warning(
            f"{skipped} row(s) were left out because no location was picked "
            "from the search list."
        )

    status_slot.markdown(theme.solving_html(), unsafe_allow_html=True)

    try:

        result = optimize_warehouses(
            customers_df,
            warehouses_df,
            max_warehouses=int(num_warehouses),
            cost_per_km=float(cost_per_km),
            max_delivery_radius=max_radius,
        )

    except Exception as error:

        status_slot.empty()
        st.error(f"The optimizer stopped with an error: {error}")
        return

    status_slot.empty()

    st.session_state.optimization_result = result

    st.session_state.optimization_inputs = {
        "customers": customers_df.copy(),
        "warehouses": warehouses_df.copy(),
    }

    if str(result.get("status", "")).lower() in ("optimal", "optimal solution"):
        st.toast("Warehouse network optimized")


if run_optimization:
    run_optimization_flow()


# ============================================================
# MAP
# ============================================================

def popup_html(title, lines):

    body = "".join(
        f"<span>{theme.esc(label)} <b>{theme.esc(value)}</b></span>"
        for label, value in lines
    )

    return f'<div class="gp-pop"><strong>{theme.esc(title)}</strong>{body}</div>'


def build_network_map(
    customers_df,
    warehouses_df,
    opened_ids,
    route_df,
    colors,
    warehouse_names,
):

    m = folium.Map(
        location=[12.9716, 77.5946],
        zoom_start=11,
        tiles="cartodbpositron",
        control_scale=True,
    )

    lats = list(customers_df["latitude"]) + list(warehouses_df["latitude"])
    lons = list(customers_df["longitude"]) + list(warehouses_df["longitude"])

    m.fit_bounds(
        [[min(lats), min(lons)], [max(lats), max(lons)]],
        padding=(48, 48),
        max_zoom=13,
    )

    m.get_root().header.add_child(folium.Element(theme.MAP_CSS))
    m.get_root().html.add_child(folium.Element(theme.map_legend()))

    customer_pos = {
        str(r["id"]): (float(r["latitude"]), float(r["longitude"]))
        for _, r in customers_df.iterrows()
    }

    warehouse_pos = {
        str(r["id"]): (float(r["latitude"]), float(r["longitude"]))
        for _, r in warehouses_df.iterrows()
    }

    orders_by_id = {
        str(r["id"]): int(r["orders"]) for _, r in customers_df.iterrows()
    }

    names_by_id = {
        str(r["id"]): str(r["name"]) for _, r in customers_df.iterrows()
    }

    max_orders = max(orders_by_id.values()) if orders_by_id else 1

    # ---- delivery routes ----------------------------------------

    assigned_to = {}

    customer_col = pick(
        route_df, "neighborhood_id", "customer_id", "customer"
    )
    warehouse_col = pick(route_df, "warehouse_id", "warehouse")
    distance_col = pick(route_df, "distance_km", "distance")

    use_animated_routes = len(route_df) <= 60

    if customer_col is not None and warehouse_col is not None:

        for _, row in route_df.iterrows():

            cid = str(row[customer_col])
            wid = str(row[warehouse_col])

            start = customer_pos.get(cid)
            end = warehouse_pos.get(wid)

            if start is None or end is None:
                continue

            assigned_to[cid] = wid

            color = colors.get(wid, theme.DEMAND)
            weight = 1.8 + 3.2 * (orders_by_id.get(cid, 0) / max_orders)

            tip = f"{names_by_id.get(cid, cid)} to {warehouse_names.get(wid, wid)}"

            if distance_col is not None:
                try:
                    tip += f" ({float(row[distance_col]):.2f} km)"
                except (TypeError, ValueError):
                    pass

            if use_animated_routes:

                AntPath(
                    locations=[start, end],
                    color=color,
                    weight=weight,
                    opacity=0.9,
                    dash_array=[6, 14],
                    delay=1500,
                    pulse_color="#FFFFFF",
                    tooltip=tip,
                ).add_to(m)

            else:

                folium.PolyLine(
                    locations=[start, end],
                    color=color,
                    weight=weight,
                    opacity=0.8,
                    dash_array="6 10",
                    tooltip=tip,
                ).add_to(m)

    # ---- neighborhoods (circles) --------------------------------

    for _, customer in customers_df.iterrows():

        cid = str(customer["id"])
        fill = colors.get(assigned_to.get(cid), theme.DEMAND)
        radius = 5 + 6 * (orders_by_id[cid] / max_orders) ** 0.5

        served_by = warehouse_names.get(assigned_to.get(cid), "Not assigned")

        folium.CircleMarker(
            location=[float(customer["latitude"]), float(customer["longitude"])],
            radius=radius,
            color="#FFFFFF",
            weight=2,
            fill=True,
            fill_color=fill,
            fill_opacity=1,
            popup=folium.Popup(
                popup_html(
                    customer["name"],
                    [
                        ("Daily orders", f"{int(customer['orders']):,}"),
                        ("Served by", served_by),
                    ],
                ),
                max_width=280,
            ),
            tooltip=folium.Tooltip(
                f"{customer['name']} · {int(customer['orders']):,} orders/day",
                sticky=True,
            ),
        ).add_to(m)

    # ---- warehouses (squares): closed first, open on top --------

    ordered = sorted(
        warehouses_df.iterrows(),
        key=lambda item: str(item[1]["id"]) in opened_ids,
    )

    for _, warehouse in ordered:

        wid = str(warehouse["id"])
        is_open = wid in opened_ids
        color = colors.get(wid, theme.CLOSED)

        status = "Open" if is_open else "Candidate left closed"

        folium.Marker(
            location=[float(warehouse["latitude"]), float(warehouse["longitude"])],
            icon=folium.DivIcon(
                html=theme.warehouse_marker_html(color, is_open),
                icon_size=(32, 32),
                icon_anchor=(16, 16),
                class_name="gp-div",
            ),
            z_index_offset=1000 if is_open else 0,
            popup=folium.Popup(
                popup_html(
                    warehouse["name"],
                    [
                        ("Status", status),
                        ("Capacity", f"{int(warehouse['capacity']):,} orders/day"),
                        ("Fixed cost", theme.money(warehouse["fixed_cost"])),
                    ],
                ),
                max_width=280,
            ),
            tooltip=folium.Tooltip(
                f"{warehouse['name']} · {status}",
                sticky=True,
            ),
        ).add_to(m)

    return m


# ============================================================
# 4  RESULTS
# ============================================================

theme.step(
    4,
    "Recommended network",
    "Which warehouses to open, what the network costs, and who each one serves.",
)


def render_results(result, saved_inputs):

    customers_df = saved_inputs["customers"].copy()
    warehouses_df = saved_inputs["warehouses"].copy()

    status = result.get("status", "Unknown")

    is_optimal = str(status).lower() in ("optimal", "optimal solution")

    if not is_optimal:

        theme.problem_panel(
            status,
            result.get("message")
            or "The solver could not find a plan that meets every limit.",
            [
                "Raise the maximum number of warehouses in the sidebar.",
                "Widen the delivery radius, or turn the limit off.",
                "Use candidates with more capacity, or raise capacity in manual mode.",
            ],
        )

        return

    # ---- normalize optimizer output -----------------------------

    opened_ids = normalize_ids(result.get("opened_warehouses", []))

    warehouse_names = {
        str(r["id"]): str(r["name"]) for _, r in warehouses_df.iterrows()
    }

    customer_names = {
        str(r["id"]): str(r["name"]) for _, r in customers_df.iterrows()
    }

    colors = {
        wid: theme.warehouse_color(i) for i, wid in enumerate(opened_ids)
    }

    metrics = dict(result.get("metrics", {}))

    metrics.setdefault("total_cost", result.get("objective") or 0)
    metrics.setdefault("total_orders", int(customers_df["orders"].sum()))

    route_df = remove_duplicate_columns(
        to_frame(result.get("assignments", []))
    )

    # ---- summary -------------------------------------------------

    theme.plan_summary(
        is_optimal,
        status,
        len(opened_ids),
        len(warehouses_df),
        metrics,
    )

    # ---- map -----------------------------------------------------

    st.write("")

    with theme.keyed_container("map_frame"):

        network_map = build_network_map(
            customers_df,
            warehouses_df,
            set(opened_ids),
            route_df,
            colors,
            warehouse_names,
        )

        st_folium(
            network_map,
            width=None,
            height=620,
            returned_objects=[],
        )

    # ========================================================
    # 5  BREAKDOWN
    # ========================================================

    theme.step(
        5,
        "Breakdown",
        "Capacity use, assignments and the file to take away.",
    )

    # ---- warehouses to open --------------------------------------

    theme.subhead("Warehouses to open")

    cards = []

    for wid in opened_ids:

        match = warehouses_df[warehouses_df["id"].astype(str) == wid]

        if match.empty:
            cards.append(
                {"name": warehouse_names.get(wid, wid), "color": colors[wid]}
            )
            continue

        row = match.iloc[0]

        cards.append(
            {
                "name": str(row["name"]),
                "capacity": row["capacity"],
                "fixed_cost": row["fixed_cost"],
                "lat": float(row["latitude"]),
                "lon": float(row["longitude"]),
                "color": colors[wid],
            }
        )

    if cards:
        theme.warehouse_cards(cards)
    else:
        st.info("The optimizer did not return any warehouses to open.")

    # ---- utilisation ---------------------------------------------

    theme.subhead(
        "Capacity used",
        "Share of each open warehouse's daily capacity that its assigned "
        "orders fill.",
    )

    util_df = remove_duplicate_columns(
        to_frame(result.get("utilization", {}), "warehouse_id", "utilization")
    )

    u_id = pick(util_df, "warehouse_id")
    u_assigned = pick(util_df, "assigned_orders", "assigned")
    u_capacity = pick(util_df, "capacity", "max_capacity")

    bar_rows = []

    if u_id and u_assigned and u_capacity:

        for wid in opened_ids:

            match = util_df[util_df[u_id].astype(str) == wid]

            if match.empty:
                continue

            row = match.iloc[0]

            bar_rows.append(
                {
                    "name": warehouse_names.get(wid, wid),
                    "assigned": float(row[u_assigned]),
                    "capacity": float(row[u_capacity]),
                    "color": colors[wid],
                }
            )

    if bar_rows:
        theme.utilization_bars(bar_rows)
    elif not util_df.empty:
        theme.data_table(util_df)
    else:
        st.info("The optimizer did not return utilization data.")

    # ---- assignments ---------------------------------------------

    theme.subhead(
        "Who is served from where",
        "Every neighborhood and the warehouse it is assigned to.",
    )

    c_id = pick(route_df, "neighborhood_id", "customer_id", "customer")
    c_name = pick(route_df, "neighborhood", "customer_name")
    w_id = pick(route_df, "warehouse_id")
    w_name = pick(route_df, "warehouse", "warehouse_name")
    c_orders = pick(route_df, "orders", "assigned_orders")
    c_distance = pick(route_df, "distance_km", "distance")
    c_cost = pick(route_df, "delivery_cost", "cost")

    table = pd.DataFrame()

    if not route_df.empty:

        if c_name:
            table["Neighborhood"] = route_df[c_name].astype(str).to_numpy()
        elif c_id:
            table["Neighborhood"] = [
                customer_names.get(str(v), str(v)) for v in route_df[c_id]
            ]

        if w_id:
            table["Warehouse"] = [
                warehouse_names.get(str(v), str(v)) for v in route_df[w_id]
            ]
        elif w_name:
            table["Warehouse"] = route_df[w_name].astype(str).to_numpy()

        if c_orders:
            table["Orders"] = route_df[c_orders].to_numpy()

        if c_distance:
            table["Distance (km)"] = route_df[c_distance].to_numpy()

        if c_cost:
            table["Delivery cost"] = route_df[c_cost].to_numpy()

    if table.empty:

        st.info("The optimizer did not return assignment data.")

    else:

        swatches = {
            warehouse_names.get(wid, wid): colors[wid] for wid in opened_ids
        }

        theme.data_table(table, colors=swatches)

        st.write("")

        st.download_button(
            "Download assignments (CSV)",
            data=table.to_csv(index=False),
            file_name="gridpoint_assignments.csv",
            mime="text/csv",
        )


result = st.session_state.optimization_result
saved_inputs = st.session_state.optimization_inputs

if result is not None and saved_inputs is not None:

    render_results(result, saved_inputs)

else:

    theme.empty_state(
        "Your plan will appear here",
        "Add your neighborhoods above, then choose Optimize warehouse "
        "network to see the recommended warehouses on a map.",
    )


# ============================================================
# FOOTER
# ============================================================

theme.footer()